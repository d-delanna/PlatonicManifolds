import conform, foundation

from regina import NTriangulation, NPerm4

def cubical_tessellation_to_tetrahedral_tessellations(t):
    """
    Takes the barycentric subdivision of a cusped cubical tessellation.
    Tries to subdivide the cubical tessellation into a tetrahedral
    tessellation. If this succeeds, returns the pair of the two tetrahedral
    tessellations from the two different choices of diagonals (might be
    combinatorially isomorphic). If the cubical tessellation cannot be
    subdivided, returns a pair (None, None)
    """

    new_t = conform.conform_vertex_order(t)

    tess = [_tetrahedral_tessellation_from_cubical(new_t, start_color)
            for start_color in range(2) ]

    assert bool(tess[0]) == bool(tess[1])
    if tess[0]:
        for it in tess:
            assert foundation.is_tetrahedral(it)

    return tess


###############################################################################
# Implementation details


def _neighborhood(trig, index, faces):
    pending = [index]
    all = set()
    while pending:
        next = pending.pop()
        if not next in all:
            all.add(next)
            for face in faces:
                pending.append(
                    trig.getTetrahedron(next).adjacentTetrahedron(face).index())
    return all

def _two_color_cubical_tessellation(trig, start_color):
    simplex_to_color = { }
    pending = [ (0, start_color) ]

    while pending:
        index, color = pending.pop()
        if not simplex_to_color.has_key(index):
            simplex_to_color[index] = color
            for face in range(4):
                if face == 0:
                    next_color = 1 - color
                else:
                    next_color = color
                next_index = (
                    trig.getTetrahedron(index)
                        .adjacentTetrahedron(face).index())
                pending.append((next_index, next_color))

    return simplex_to_color

def _is_two_coloring_consistent(trig, simplex_to_color):
    for i in range(trig.getNumberOfTetrahedra()):
        for face in range(4):
            if face == 0:
                color = 1 - simplex_to_color[i]
            else:
                color = simplex_to_color[i]
            if not color == simplex_to_color[
                trig.getTetrahedron(i).adjacentTetrahedron(face).index()]:
                return False
    return True

def _index_cubes_and_colored_cube_corners(t, simplex_to_color):
    num = t.getNumberOfTetrahedra()

    simplex_to_cube = {}
    simplex_to_cube_corner = {}
    current_cube = 0
    for simp in range(num):
        if not simplex_to_cube.has_key(simp):
            # Process the entire cube
            current_cube_corner = 0
            for simp_in_cube in _neighborhood(t, simp, (0, 1, 2)):
                simplex_to_cube[simp_in_cube] = current_cube

                if (simplex_to_color[simp_in_cube] and not
                    simplex_to_cube_corner.has_key(simp_in_cube)):

                    for simp_in_cube_corner in _neighborhood(t, simp_in_cube, (1, 2)):
                        simplex_to_cube_corner[simp_in_cube_corner] = current_cube_corner
                    current_cube_corner += 1

            current_cube += 1

    return simplex_to_cube, simplex_to_cube_corner

def _build_cubes_from_tets(numCubes):
    tess = NTriangulation()
    tets = [ tess.newTetrahedron() for i in range(5 * numCubes) ]
    
    for i in range(numCubes):
        for j in range(4):
            tets[5*i].joinTo(j, tets[5*i+1+j], NPerm4())

    return tess

def _perm(config0, config1):
    return NPerm4(config0[0],config1[0],
                  config0[1],config1[1],
                  config0[2],config1[2],
                  config0[3],config1[3])

def _tetrahedral_tessellation_from_cubical(t, start_color):
    num = t.getNumberOfTetrahedra()
    numCubes = num / 48

    tess = _build_cubes_from_tets(numCubes)

    simplex_to_color = _two_color_cubical_tessellation(t, start_color)
    
    if not _is_two_coloring_consistent(t, simplex_to_color):
        return None

    simplex_to_cube, simplex_to_colored_cube_corner = (
        _index_cubes_and_colored_cube_corners(t, simplex_to_color))

    def _get_tet_with_config_from_uncolored_simplex(i):
        simplex = t.getTetrahedron(i)
        cube = simplex_to_cube[i]
        verts = (
            simplex_to_colored_cube_corner[
                _follow_neighbors(simplex, (0,)    ).index()],
            simplex_to_colored_cube_corner[
                _follow_neighbors(simplex, (1,0 )  ).index()],
            simplex_to_colored_cube_corner[
                _follow_neighbors(simplex, (2,1,0 )).index()])
        remaining_vertex = 6 - sum(verts)
        config = (remaining_vertex, verts[0], verts[1], verts[2])
        
        tet = tess.getTetrahedron(5 * cube + 1 + config[0])
        return tet, config

    for i in range(num):
        if not simplex_to_color[i]:
            tet0, config0 = _get_tet_with_config_from_uncolored_simplex(i)
            if not tet0.adjacentTetrahedron(config0[3]):
                tet1, config1 = _get_tet_with_config_from_uncolored_simplex(
                    t.getTetrahedron(i).adjacentTetrahedron(3).index())
                
                tet0.joinTo(config0[3], tet1, _perm(config0, config1))
        
    return tess

def _follow_neighbors(tet, faces):
    for face in faces:
        tet = tet.adjacentTetrahedron(face)
    return tet
