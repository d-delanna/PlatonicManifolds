import readDataFiles

import os
import re
import glob

def _base(path):
    return os.path.split(path)[0]

baseDir = os.path.join(_base(__file__), '../data')

kindToSymbol = {
    'tet'     : '336',
    'oct'     : '344',
    'cubecld' : '435',
    'cube'    : '436',
    'icocld'  : '353',
    'dodecld' : '535',
    'dode'    : '536'
}

class CensusDatabase(object):

    _filebaseToDatabase = {}

    @staticmethod
    def get(filebase):
        if not filebase in CensusDatabase._filebaseToDatabase:
            CensusDatabase._filebaseToDatabase[filebase] = (
                CensusDatabase(filebase))
        return CensusDatabase._filebaseToDatabase[filebase]
    
    @staticmethod
    def get_entry(name):
        orientability, kind = re.match('([no])([a-z]+?)?\d+_\d+', name).groups()
        db = CensusDatabase(
            'namedIsometric_%s%s_up_to' % (
                orientability, kindToSymbol[kind]))
            
        index = db.nameToIndex[name]
        return db.entries[index]
    
    def __init__(self, filebase, baseDir = baseDir):
        
        pattern = os.path.join(baseDir, filebase) + '*.txt'
        filePaths = glob.glob(pattern)
        if len(filePaths) > 1:
            raise Exception("No unique file '%s'" % pattern)
        if len(filePaths) == 0:
            raise Exception("No file '%s'" % pattern)

        f = open(filePaths[0])
        
        self.entries = readDataFiles.parse_text(f.read())

        self.nameToIndex = {
            name : i
            for i, (name, isoSigs, isometrySig) in enumerate(self.entries)
            }

        self.isoSigToIndex = {
            isoSig : (i, j)
            for i, (name, isoSigs, isometrySig) in enumerate(self.entries)
            for j, isoSig in enumerate(isoSigs)
            }
        
        self.isometrySigToIndex = {
            isometrySig : i
            for i, (name, isoSigs, isometrySig) in enumerate(self.entries)
            }

    
