from regina import NTriangulation

from censusDatabase import CensusDatabase, kindToSymbol
from tessellationProperties import tessellation_properties
from cubical import cubical_tessellation_to_tetrahedral_tessellations
import readDataFiles

import sys
import re

def print_properties(name):

    print "Properties of %s" % name,

    isCubical = re.match('[no]cube\d+_\d+', name)
    isTetrahedral = re.match('[no]tet\d+_\d+', name)

    entry = CensusDatabase.get_entry(name)

    tet_entry = None

    if isCubical:
        db = CensusDatabase.get('namedIsometric_%s336_up' % name[0])
        if entry[2] in db.isometrySigToIndex:
            tet_entry = db.entries[db.isometrySigToIndex[entry[2]]]
            print "  (isometric to %s)" % tet_entry[0],

    isosig_to_coarsend_cube = {}

    if isTetrahedral:
        db = CensusDatabase.get('namedIsometric_%s436_up' % name[0])
        if entry[2] in db.isometrySigToIndex:
            cube_entry = db.entries[db.isometrySigToIndex[entry[2]]]
            print "  (isometric to %s)" % cube_entry[0],
            
            for i, isoSig in enumerate(cube_entry[1]):
                cubical = NTriangulation.fromIsoSig(isoSig)
                tetrahedrals = (
                    cubical_tessellation_to_tetrahedral_tessellations(cubical))
                if tetrahedrals:
                    for tetrahedral in tetrahedrals:
                        key = tetrahedral.isoSig()
                        value = '%s#%d' % (cube_entry[0], i)
                        isosig_to_coarsend_cube.setdefault(
                            key, set()).add(value)

    print


    print "  Number of tessellations: %d" % len(entry[1])

    canonical = (
        NTriangulation.fromIsoSig(entry[2])
        if not readDataFiles.fake_isometry_signature_prefix in entry[2]
        else None)
    if canonical:
        isomets   = len(canonical.findAllIsomorphisms(canonical))

        

    for i, isoSig in enumerate(entry[1]):
        trig = NTriangulation.fromIsoSig(isoSig)

        print "  %s#%d: " % (name, i),
        properties = tessellation_properties(trig)

        for k in ['self_dual', 'regular', 'chiral']:

            print k,
            if properties[k]:
                print " YES  ",
            else:
                print " -    ",

        if canonical:
            print "hidesSyms",
            comb_isos = len(trig.findAllIsomorphisms(trig))

            if comb_isos != isomets:
                print " YES  (%3d/%3d)" % (comb_isos, isomets),
            else:
                print " -    (    %3d)" % isomets,

        if tet_entry:
            tetrahedrals = cubical_tessellation_to_tetrahedral_tessellations(
                trig)
            if tetrahedrals:
                names = set()
                for tetrahedral in tetrahedrals:
                    try:
                        index = tet_entry[1].index(tetrahedral.isoSig())
                        names.add('%s#%d' % (tet_entry[0], index))
                    except ValueError:
                        pass
                names = sorted(names)
                if names:
                    print "  (subdivides to %s)" % (', '.join(names)),

        if isoSig in isosig_to_coarsend_cube:
            print "  (coarsens to %s)" % (
                ', '.join(sorted(isosig_to_coarsend_cube[isoSig]))),

        print
    print
    print
    
if __name__ == '__main__':
    if len(sys.argv) == 1:
        print "Usage: python showProperties.py MANIFOLDNAME [MANIFOLDNAME] ..."
        print "  e.g. python showProperties.py otet05_00001"
        print "       python showProperties.py CENSUSNAME"
        print "  e.g. python showProperties.py ocube"
        sys.exit(1)

    if (len(sys.argv) == 2 and
        sys.argv[1][0] in 'on' and
        sys.argv[1][1:] in kindToSymbol):

        db = CensusDatabase.get('namedIsometric_%s%s_up_to' % (
                sys.argv[1][0], kindToSymbol[sys.argv[1][1:]]))
        for entry in db.entries:
            print_properties(entry[0])
    else:
        for name in sys.argv[1:]:
            print_properties(name)

