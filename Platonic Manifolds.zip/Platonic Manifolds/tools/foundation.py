from regina import NTriangulation, NPerm4

def is_tetrahedral(t):
    """
    Returns true if all edges of a triangulation have order 6.
    """
    tet = t.getTetrahedron(0)
    for i in range(6):
        if tet.getEdge(i).getDegree() != 6:
            return False
    return True

def dual_tessellation(t):
    """
    Given a non-tetrahedral Platonic tessellation, returns its dual.
    """
    assert not is_tetrahedral(t), "Cannot dualize tetrahedral tessellation"

    return _apply_perm_to_triangulation(NPerm4(3,2,1,0), t)

def gap_symmetry_group_from_triangulation(trig):
    """
    Given a triangulation, returns the GAP representation of the combinatorial
    automorphism group.
    """
    _ensure_regina_version()
    isos = trig.findAllIsomorphisms(trig)
    
    perms = [ "PermList(%s)" % str(_perm_from_iso(iso)) for iso in isos ]
    return "Group(%s)" % ",".join(perms)


###############################################################################
# Implementation details

def _apply_perm_to_triangulation(perm, t):
    new_t = NTriangulation()
    new_tets = [ new_t.newTetrahedron()
                 for i in range(t.getNumberOfTetrahedra())]

    for i, tet in enumerate(t.getTetrahedra()):
        for f in range(4):
            if not new_tets[i].adjacentTetrahedron(perm[f]):
                new_tets[i].joinTo(
                    perm[f],
                    new_tets[tet.adjacentTetrahedron(f).index()],
                    NPerm4())

    assert t.isIsomorphicTo(new_t)

    return new_t

def _perm_from_iso(iso):
    return [4 * iso.tetImage(t) + iso.facePerm(t)[v] + 1
            for t in range(iso.getSourceTetrahedra())
            for v in range(4)]

def _ensure_regina_version():
    if not hasattr(NTriangulation, "findAllIsomorphisms"):
        print "Old version of Regina detected. The version currently in use "
        print "is lacking the following change: "
        print "http://sourceforge.net/u/matthiasgoerner/regina/ci/bae9206f484570e284da291e9b899072e0beb676/"
        print "As of 09/14/2015, there is no Regina release yet with this "
        print "change yet. You might need to compile your own Regina from "
        print "checked-out source."
        raise Exception("Regina versions lacks findAllIsomorphsims.")

