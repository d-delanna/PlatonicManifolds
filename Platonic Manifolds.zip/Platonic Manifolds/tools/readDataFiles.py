# Methods to parse the file format where each line is of the form
# Name ListOfIsomorphismSignatures IsometrySignature
#
# Example:
# otet08_0002 iLLLQPcceegfghhhiimaimimi ivvPQQcgfhfhgfghappppaaaa mvLLwMAQQdfeihgjlkkjlloafaofoqfofaq

import re

def parse_line(line):
    l = [ isoSig.strip() for isoSig in line.split() if isoSig.strip() ]
    return l[0], l[1:-1], l[-1]

# Parse such a file, result is a list of triples
#   (name, list of isomorphism signatures, isometry signature)
def parse_text(lines):
    return [ parse_line(line) for line in lines.split('\n') if line.strip() ]

_solid_dict = {'tet'  : 'Tetrahedra',
               'oct'  : 'Octahedra',
               'cube' : 'Cubes',
               'dode' : 'Dodecahedra',
               'ico'  : 'Icosahedra'
               }
               

# From a name such as otet06_0003 and returns ("Tetrahedra", 6)
def get_solid_and_number(name):
    solid, closed, number = re.match('[no]([a-z]+?)(cld)?(\d+)_\d+', name).groups()
    return _solid_dict[solid], int(number)

fake_isometry_signature_prefix = 'fake__'
