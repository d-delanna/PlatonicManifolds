def find_morphisms(src, dst):
    """
    Finds all covering maps from the regina triangulation src to dst
    (covering maps preserving the triangulations, src is the larger
    space).

    >>> from regina import NExampleTriangulation
    >>> from regina import NTriangulation

    >>> A = NExampleTriangulation.figureEightKnotComplement()
    
    This finds all combinatorial automorphisms:
    >>> morphs = find_morphisms(A, A)
    >>> len(morphs)
    8

    A morphism is just a list of integers:
    >>> morphs[5]
    [5, 4, 7, 6, 1, 0, 3, 2]

    We index the vertex i of tetrahedron j by 4 * j + i.

    >>> morphs[5][7]
    2

    For the above morphism, the integer at position 7 = 4 * 1 + 3
    is 2 = 4 * 0 + 2.
    This means that the tetrahedron 1 is send to tetrahedron 0
    such that vertex 3 of it goes to vertex 2 of the other tetrahedron.

    This is the double cover of the figure-8 knot complement
    >>> Dcover = NTriangulation.fromIsoSig('eLMkbcdddhxqdu')
    >>> morphs2 = find_morphisms(Dcover, A)

    Thus we have morphisms
    >>> len(morphs2)
    8

    But not in the other way
    >>> find_morphisms(A, Dcover)
    []

    Two unrelated triangulations:
    >>> find_morphisms(A, NExampleTriangulation.poincareHomologySphere())
    []
    
    Some more tests:
    >>> morphs
    [[0, 1, 2, 3, 4, 5, 6, 7], [1, 0, 3, 2, 5, 4, 7, 6], [2, 3, 1, 0, 7, 6, 4, 5], [3, 2, 0, 1, 6, 7, 5, 4], [4, 5, 6, 7, 0, 1, 2, 3], [5, 4, 7, 6, 1, 0, 3, 2], [6, 7, 5, 4, 3, 2, 0, 1], [7, 6, 4, 5, 2, 3, 1, 0]]
    >>> morphs2
    [[0, 3, 1, 2, 5, 6, 7, 4, 6, 7, 5, 4, 3, 2, 1, 0], [1, 2, 0, 3, 4, 7, 6, 5, 7, 6, 4, 5, 2, 3, 0, 1], [2, 0, 3, 1, 6, 4, 5, 7, 4, 5, 6, 7, 0, 1, 3, 2], [3, 1, 2, 0, 7, 5, 4, 6, 5, 4, 7, 6, 1, 0, 2, 3], [4, 7, 5, 6, 1, 2, 3, 0, 2, 3, 1, 0, 7, 6, 5, 4], [5, 6, 4, 7, 0, 3, 2, 1, 3, 2, 0, 1, 6, 7, 4, 5], [6, 4, 7, 5, 2, 0, 1, 3, 0, 1, 2, 3, 4, 5, 7, 6], [7, 5, 6, 4, 3, 1, 0, 2, 1, 0, 3, 2, 5, 4, 6, 7]]

    """

    src_num_tet = src.getNumberOfTetrahedra()
    dst_num_tet = dst.getNumberOfTetrahedra()

    result = []

    # If the src triangulations doesn't have a multiple of tetrahedra
    # of the dst, bail with empty list
    if not src_num_tet % dst_num_tet == 0:
        return result

    # Iterate through all tets of dst
    for dst_tet_index in range(dst_num_tet):
        # Iterate through all perms
        for perm in NPerm4.S4:
            # Try to construct a morphism sending the first tetrahedron
            # to the tetrahedron dst using perm

            # We construct a partial morphism that is just as described
            # by filling it with None
            imgFirstTet  = [ 4 * dst_tet_index + perm[k] for k in range(4) ]
            imgOtherTets = (src_num_tet - 1) * [ None, None, None, None ]
            morphism = imgFirstTet + imgOtherTets

            # Try to extend the morphism, add result on success
            if _extend_morphism(morphism, src, dst) == "done":
                result.append(morphism)

    return result


###############################################################################
# Implementation details

def _extend_morphism(morphism, src, dst):
    """
    Extend the partial morphism (has None's) from src to dst until
    either finished (returning "done") or running into inconsistencies.
    """

    while True:
        # Try extending by one more tet
        result = _extend_morphism_by_one(morphism, src, dst)
        # If done, return result
        # If it returns "done", it means that the morphism was
        # full and it iterated through it to check consistency.
        if not result == "extended":
            return result

def _extend_morphism_by_one(morphism, src, dst):
    """
    Extend the partial morphism by one tetrahedron.
    """

    # Iterate through all tetrahedra in src

    for src_tet1_index in range(len(morphism) / 4):
        # The first src tetrahedron
        src_tet1 = src.getTetrahedron(src_tet1_index)
        # The four vertices of it
        src_tet1_verts = [ 0, 1, 2, 3 ]

        # Their images
        img_verts = [ morphism[4 * src_tet1_index + v]
                      for v in src_tet1_verts ]

        # If the morphisms assigns the first src tet an image, called
        # first dst tet, try to extend the morphism.
        if not None in img_verts:

            # The verts of the dst tet corresponding to the src tet verts
            dst_tet1_verts = [ v % 4 for v in img_verts ]
            # The index of dst tet
            dst_tet1_index = img_verts[0] / 4
            # The dst tet itself
            dst_tet1 = dst.getTetrahedron(dst_tet1_index)

            # Now try to extend the morphism by looking at the neighbor
            # of the src tet across face src_face_tet1.
            # src tet's neighbor (called second src tet) has to go to
            # the neighbor of dst tet along face dst_face_tet1.
            for src_face_tet1, dst_face_tet1  in zip(src_tet1_verts,
                                                     dst_tet1_verts):

                # The src tet's neighbor
                src_tet2 = src_tet1.adjacentTetrahedron(src_face_tet1)
                src_tet2_index = src.tetrahedronIndex(src_tet2)
                src_tet2_verts = [ src_tet1.adjacentGluing(src_face_tet1)[v]
                                   for v in src_tet1_verts ]
                
                # The dst tet's neighbor
                dst_tet2 = dst_tet1.adjacentTetrahedron(dst_face_tet1)
                dst_tet2_index = dst.tetrahedronIndex(dst_tet2)
                dst_tet2_verts = [ dst_tet1.adjacentGluing(dst_face_tet1)[v]
                                   for v in dst_tet1_verts ]

                # The morphism has to send src tet's neighbor to dst tet's
                # neighbor such that src_tet2_verts go to dst_tet2_verts.
                # We construct this slice of the morphism corresponding to
                # src tet.
                new_tet_morphism = 4 * [ None ]
                for k in range(4):
                    new_tet_morphism[src_tet2_verts[k]] = (
                        4 * dst_tet2_index + dst_tet2_verts[k])

                # And get the old slice of the morphism corresponding to
                # src tet.
                old_tet_morphism = morphism[
                    4 * src_tet2_index : 4 * src_tet2_index + 4]

                # If the morphism didn't assign the src tet's neighbor
                # anything, we extend the morphism.
                if None in old_tet_morphism:
                    morphism[4 * src_tet2_index : 4 * src_tet2_index + 4] = (
                        new_tet_morphism)
                    return "extended"
                
                # Otherwise, check whether the mapping of src tet's
                # neighbor we get using this face-pairing agrees with
                # that from a previous iteration.
                # If not, this does not produce a consistent morphism:
                if old_tet_morphism != new_tet_morphism:
                    return "inconsistent"

    # Iterated through, the morphism isn't partial and it is consistent.
    return "done"
