from regina import NPerm4, NEdge

import foundation

def conform_vertex_order(t):
    """
    Relabels the vertices of the simplices of a barycentric subdivision of
    a Platonic tessellation so that it follows the convention that a vertex 3
    cooresponds to the center of a solid, a vertex 2 to a face center, ...
    """

    if foundation.is_tetrahedral(t):
        return t

    perm = _find_relabel_perm(t)
    if perm == NPerm4():
        return t

    new_t = foundation._apply_perm_to_triangulation(perm, t)
    assert _are_valid_orders(_edge_orders(new_t))
    return new_t

###############################################################################
# Implementation details

def _edge_orders(t):
    tet = t.getTetrahedron(0)
    return [  [ tet.getEdge(5-NEdge.edgeNumber[i][j]).getDegree()
                if i != j else 0
                for i in range(4) ]
              for j in range(4)]

def _are_valid_orders(orders):
    for i in range(2):
        for j in range(i+2,4):
            if not orders[i][j] == 4:
                return False

    return orders[2][3] >= orders[0][1]

def _find_relabel_perm(t):
    orders = _edge_orders(t)
    for perm in NPerm4.S4:
        new_orders = [  [orders[perm[i]][perm[j]] for i in range(4) ]
                        for j in range(4) ]
        if _are_valid_orders(new_orders):
            return perm.inverse()
