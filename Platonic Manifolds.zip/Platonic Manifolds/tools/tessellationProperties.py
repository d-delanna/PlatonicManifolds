import foundation

from regina import NPerm4, NTriangulation

def tessellation_properties(t):
    """
    Given tetrahedral tessellation or a barycentric subdivision of a Platonic
    tessellation, returns a dictionary
    {
       'self_dual': BOOLEAN,
       'regular': BOOLEAN,
       'chiral': BOOLEAN
    }

    Note a tessellation can be chiral while the manifold is amphicheiral.
    """

    if foundation.is_tetrahedral(t):
        return _tetrahedral_tessellation_properties(t)
    else:
        return _nontetrahedral_tessellation_properties(t)

###############################################################################
# Implementation details

def _nonorientable_tetrahedral_tessellation_properties(t):
    foundation._ensure_regina_version()
    return {
        'self_dual': False,
        'regular': len(t.findAllIsomorphisms(t)) == 24 * t.getNumberOfTetrahedra(),
        'chiral': False
        }

def _orientable_tetrahedral_tessellation_properties(t):
    foundation._ensure_regina_version()
    tcopy = NTriangulation(t)
    tcopy.orient()
    isos = tcopy.findAllIsomorphisms(tcopy)
    chiral = not any([iso.facePerm(0).sign() < 0 for iso in isos])
    symTet = 12 if chiral else 24

    return {
        'self_dual': False,
        'regular': len(isos) == symTet * t.getNumberOfTetrahedra(),
        'chiral': chiral
        }

def _tetrahedral_tessellation_properties(t):
    if t.isOrientable():
        return _orientable_tetrahedral_tessellation_properties(t)
    else:
        return _nonorientable_tetrahedral_tessellation_properties(t)

def _indices_of_all_right_handed_simplices(t):
    pending_right_handed_simplices = [ 0 ]
    all_right_handed_simplices = set()
    while pending_right_handed_simplices:
        next_right_handed_simplex = pending_right_handed_simplices.pop()
        if not next_right_handed_simplex in all_right_handed_simplices:
            all_right_handed_simplices.add(next_right_handed_simplex)
            for face0 in range(4):
                for face1 in range(4):
                    neighbor_of_neighbor = (
                        t.getTetrahedron(next_right_handed_simplex)
                         .adjacentTetrahedron(face0)
                         .adjacentTetrahedron(face1)
                         .index())
                    pending_right_handed_simplices.append(neighbor_of_neighbor)
    return all_right_handed_simplices

def _split_isomorphisms_by_permutation(isos):
    isos_identity = []
    isos_flip = []
    for iso in isos:
        if iso.facePerm(0) == NPerm4():
            isos_identity.append(iso)
        else:
            isos_flip.append(iso)
    return isos_identity, isos_flip

def _images_of_zero_simplex(isos):
    return set([iso.simpImage(0) for iso in isos])

def _nontetrahedral_tessellation_properties(t):
    foundation._ensure_regina_version()
    right_handed_simplices = _indices_of_all_right_handed_simplices(t)
    isos = t.findAllIsomorphisms(t)
    isos_identity, isos_flip = _split_isomorphisms_by_permutation(isos)
    images_of_zero_simplex_identity = _images_of_zero_simplex(isos_identity)
    
    return {
        'self_dual' :  bool(isos_flip),
        'regular' : right_handed_simplices.issubset(
            images_of_zero_simplex_identity),
        'chiral' : t.isOrientable() and not (
             images_of_zero_simplex_identity.difference(right_handed_simplices))
        }
