                ``A census of hyperbolc Platonic manifolds
                                     and
                     augmented knotted trivalent graphs''

                                (arxiv version)

                                Matthias Goerner


Table of Contents

   1. Introduction
   2. snappy/       Platonic manifolds as SnapPy census
   3. regina/       Platonic tessellations as Regina census
   4. data/         Platonic census as text files
   5. AugKTG/data/  Augmented knotted trivalent graphs as text files
   6. tools/        Tools for investigating Platonic tessellations
   7. src/          Algorithms to enumerate Platonic tessellations
   8. python/       Tools for creating census

*******************************************************************************
* 1. Introduction                                                             *
*******************************************************************************

This directory contains source and data files accompanying the paper. Details
of how the census was created are described in the file CENSUS_CREATION.txt.
Similarly, see AugKTG/LINK_CREATION.txt for the augmented knotted trivalent
graphs.

The data contains the census of all Platonic tessellations and Platonic
manifolds up to the number of solids in the following table:

                                    Orientable    Nonorientable
     Cusped Tetrahedral   {3,3,6}       25             21
     Cusped Octahedral    {3,4,4}      7/8            5/6
     Cusped Cubical       {4,3,6}        7            5/6
     Cusped Doecahedral   {5,3,6}        2              2
     Closed Icosahedral   {3,5,3}        4              3
     Closed Cubical       {4,3,5}       10             10
     Closed Dodecahedral  {5,3,5}        3              2

An entry such as 7/8 refers to the number of solids in the small and large
version of the census.

The small version of the census is shipped with SnapPy 2.4 and available at

         http://unhyperbolic.org/platonicCensus/small/

The large version (which is too large too be shipped with SnapPy) is available
at 
         http://unhyperbolic.org/platonicCensus/large/

For convenience, there are also corresponding tar files available at

         http://unhyperbolic.org/platonicCensus/

Due to size limitations, the Arxiv has only the source code to produce the
census but not the data.

*******************************************************************************
* 2. snappy/       Platonic manifolds as SnapPy census                        *
*******************************************************************************

The small version of the census is already available in SnapPy 2.4 and
can be used just like any other SnapPy census:

>>> TetrahedralOrientableCuspedCensus['otet02_00001']
otet02_00001(0,0)
>>> len(OctahedralNonorientableCuspedCensus(solids = 4)) # with 4 octahedra
3076
>>> # with 4 tetrahedra, 2 cusps
>>> list(TetrahedralOrientableCuspedCensus(solids=4,cusps=2))
[otet04_00000(0,0)(0,0), otet04_00001(0,0)(0,0)]
>>> OctahedralOrientableCuspedCensus.identify(Manifold("t12057"))
ooct02_00008(0,0)(0,0)

For the large version of census, go to the "snappy" directory and within
SnapPy, python, or sage, simply type the following before using the above
examples (requires SnapPy 2.4):

>>> from platonicCensus import *

Depending on your python settings, you might need to run the following to
import platonicCensus from the current directory:

>>> import sys; sys.path.append('.')

*******************************************************************************
* 3. regina/       Platonic tessellations as Regina census                    *
*******************************************************************************

Due to size limitations, the regina files are not included in the arxiv
version.

The "regina" directory contains various rga files for the Platonic census.

The difference to the SnapPy census is that the barycentric subdivisions (in
the non-tetrahedral cases) of the different Platonic tessellations for the same
manifold are listed, grouped under a node for the corresponding Platonic
manifold, together with its canonical retriangulation (if cusped).

regina/example.py gives an example of how to access the triangulations in the
regina files using the python API (for Regina 4.96).

*******************************************************************************
* 4. data/         Platonic census as text files                              *
*******************************************************************************

The files "namedIsometric_..." group the tessellations yielding the same
manifold into one line where each line is of the form

         name listOfIsomorphismSignatures isometrySignature

where listOfIsomorphismSignatures is a list of isomorphism signatures of the
barycentric subdivisions (in non-tetrahedral case) of the different Platonic
tessellations for the same Platonic manifold, which has the listed isometry
signature (or special invariant in closed case).

*******************************************************************************
* 5. AugKTG/data/  Augmented knotted trivalent graphs as text files           *
*******************************************************************************

The file "AugKTG/data/OctMfdToLink..." contains the alphabetic DT codes of
the augmented knotted trivalent graphs (AugKTGs). Each line has the following
three items:

  - Name of the octahedral manifold that is the AugKTG's complement
  - decorated isomorphism signature of the AugKTG's complement
  - alphabetic DT code of the link

The corresponding diagrams can be found as svg's and pdf's in AugKTG/diagrams.

*******************************************************************************
* 6. tools/        Tools for investigating Platonic tessellations             *
*******************************************************************************

This directory contains various files with methods to investigate properties of
tessellations (requires regina version later than 4.96, see below).
One script prints out a summary of these properties given a manifold name:

     python tools/showProperties.py otet10_00027

results in:

Properties of otet10_00027   (isometric to ocube02_00025)
  Number of tessellations: 2
  otet10_00027#0: self_dual - regular -   chiral - hidesSyms YES (48/240) (coarsens to ocube02_00025#0)
  otet10_00027#1: self_dual - regular YES chiral - hidesSyms -   (   240) (coarsens to ocube02_00025#0)

This means, for example, that the manifold otet10_00027 has two tetrahedral
tessellations, both of which are obtained by subdiving the cubes of the cubical
tessellation ocube02_00025 into 5 tetrahedra each.
One of these tetrahedral tessellations is regular and the combinatorial
isomorphisms of the tessellations and the isometries of the manifold are the
same, namely, there are 240. The other tetrahedral tessellation has less
combinatorial isomorphisms (only 48), so it hides symmetries.

Several manifolds can be listed:

     python tools/showProperties.py oicocld04_00009 oicocld04_00010

Or an entire census at once:

    python tools/showProperties.py otet

This tool requires features that have been contributed to Regina after version
4.96 and have not appeared in a release yet - as of writing this -, so Regina
must be compiled from source for now.

*******************************************************************************
* 7. src/          Algorithm to enumerate Platonic tessellations              *
*******************************************************************************

This folder contains the C++ code for the new algorithm to enumerate the
Platonic tessellations as described in the paper.

*******************************************************************************
* 8. python/       Tools for creating censuses                                *
*******************************************************************************

Various helpers used to create the census. See CENSUS_CREATION.txt for details.
