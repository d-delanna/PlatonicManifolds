"""
Platonic census.
"""

__all__ = ['TetrahedralOrientableCuspedCensus',
           'TetrahedralNonorientableCuspedCensus',
           'OctahedralOrientableCuspedCensus',
           'OctahedralNonorientableCuspedCensus',
           'CubicalOrientableCuspedCensus',
           'CubicalNonorientableCuspedCensus',
           'DodecahedralOrientableCuspedCensus',
           'DodecahedralNonorientableCuspedCensus',
           'IcosahedralNonorientableClosedCensus',
           'IcosahedralOrientableClosedCensus',
           'CubicalNonorientableClosedCensus',
           'CubicalOrientableClosedCensus',
           'DodecahedralNonorientableClosedCensus',
           'DodecahedralOrientableClosedCensus'
           ]

import os.path

import snappy

if not snappy.version()[:3] == '2.4':
    print("Warning, these databases have only been tested against SnapPy "
          "version 2.4 and ")
    print("you are using version %s." % snappy.version())
    print("")
    print("They might not work because the SnapPy database format might "
          "have changed.")
    print("")
    print("News about possible future updates to these files for other SnapPy "
          "versions ")
    print("will be posted at:")
    print("     http://unhyperbolic.org/platonicCensus/versions.txt")

from snappy import Manifold
from snappy.database import ManifoldTable
from spherogram import DTcodec

# Get the path 
base_path = os.path.split(os.path.abspath(__file__))[0]

class IsosigManifoldTable(ManifoldTable):
    """
    Iterator for cusped manifolds in an sqlite3 table of manifolds.

    Initialize with the table name.  The table schema is required to
    include a text field called 'name' and a text field called
    'triangulation'.  The text holds the result of
    M.triangulation_isosig(), M.triangulation_isosig(decorated = True), or
    M._to_string().

    Both mapping from the manifold name, and lookup by index are
    supported.  Slicing can be done either by numerical index or by
    volume.

    The __contains__ method is supported, so M in T returns True if M
    is isometric to a manifold in the table T.  The method
    T.identify(M) will return the matching manifold from the table.
    """

    # basic select clause.  Can be overridden, e.g. to additional columns
    _select = 'select name, triangulation from %s '

    def _check_schema(self):
        assert (self.schema['name'] == 'text' and 
                self.schema['triangulation'] == 'text'
                ), 'Not a valid Manifold table.'
        
    def _manifold_factory(self, cursor, row, M=None):
        """
        Factory for "select name, triangulation" queries.
        Returns a Manifold.
        """

        M = Manifold(row[1])
        self._finalize(M, row)
        return M

    def _finalize(self, M, row):
        """
        Give the manifold a name.  Override this method for custom manifold
        production.
        """
        M.set_name(row[0])

class IsosigPlatonicManifoldTable(IsosigManifoldTable):
    """
    Iterator for platonic hyperbolic manifolds.
    """

    def _configure(self, **kwargs):
        IsosigManifoldTable._configure(self, **kwargs)
        conditions = []

        if 'solids' in kwargs:
            N = int(kwargs['solids'])
            conditions.append('solids = %d' % N)
            
        if self._filter:
            if len(conditions) > 0:
                self._filter += (' and ' + ' and '.join(conditions))
        else:
            self._filter = ' and '.join(conditions)

class TetrahedralOrientableCuspedTable(IsosigPlatonicManifoldTable):
    """
    Iterator for the tetrahedral orientable cusped hyperbolic manifolds up to
    25 tetrahedra, i.e., manifolds that admit a tessellation by regular ideal
    hyperbolic tetrahedra.
    """

    def __init__(self, **kwargs):
        return IsosigPlatonicManifoldTable.__init__(
            self,
            'tetrahedral_orientable_cusped_census',
            db_path = os.path.join(base_path, "tetrahedralOrientableCuspedCensus.sqlite"),
            **kwargs)

class TetrahedralNonorientableCuspedTable(IsosigPlatonicManifoldTable):
    """
    Iterator for the tetrahedral non-orientable cusped hyperbolic manifolds up to
    21 tetrahedra, i.e., manifolds that admit a tessellation by regular ideal
    hyperbolic tetrahedra.
    """

    def __init__(self, **kwargs):
        return IsosigPlatonicManifoldTable.__init__(
            self,
            'tetrahedral_nonorientable_cusped_census',
            db_path = os.path.join(base_path, "tetrahedralNonorientableCuspedCensus.sqlite"),
            **kwargs)

if not os.path.exists("octahedralOrientableCuspedCensusWithAugKTG.sqlite"):

    class OctahedralOrientableCuspedTable(IsosigPlatonicManifoldTable):
        """
        Iterator for the octahedral orientable cusped hyperbolic manifolds up to
        7 octahedra, i.e., manifolds that admit a tessellation by regular ideal
        hyperbolic octahedra.
        """

        def __init__(self, **kwargs):
            return IsosigPlatonicManifoldTable.__init__(
                self,
                'octahedral_orientable_cusped_census',
                db_path = os.path.join(base_path, "octahedralOrientableCuspedCensus.sqlite"),
                **kwargs)

else:
    class OctahedralOrientableCuspedTable(IsosigPlatonicManifoldTable):
        """
        Iterator for the octahedral orientable cusped hyperbolic manifolds up to
        7 octahedra, i.e., manifolds that admit a tessellation by regular ideal
        hyperbolic octahedra.

        If a manifold is also the complement of an
        Augmented Knoted Trivalent Graph (AugKTG), the link is included and can
        be shown with plink(). Supply isAugKTG = True, to only see manifolds
        that are complements of AugKTGs.
        """

        _select = 'select name, triangulation, DT from %s '

        def __init__(self, **kwargs):
            return IsosigPlatonicManifoldTable.__init__(
                self,
                'octahedral_orientable_cusped_census',
                db_path = os.path.join(base_path, "octahedralOrientableCuspedCensusWithAugKTG.sqlite"),
                **kwargs)
        
        def _configure(self, **kwargs):
            IsosigPlatonicManifoldTable._configure(self, **kwargs)
            conditions = []
            
            if 'isAugKTG' in kwargs:
                if kwargs['isAugKTG']:
                    conditions.append('isAugKTG = 1')
                else:
                    conditions.append('isAugKTG = 0')
                    
            if self._filter:
                if len(conditions) > 0:
                    self._filter += (' and ' + ' and '.join(conditions))
            else:
                self._filter = ' and '.join(conditions)

        def _finalize(self, M, row):
            IsosigPlatonicManifoldTable._finalize(self, M, row)
            if row[2]:
                M._set_DTcode(DTcodec(row[2]))
        

class OctahedralNonorientableCuspedTable(IsosigPlatonicManifoldTable):
    """
    Iterator for the octahedral non-orientable cusped hyperbolic manifolds up to
    5 octahedra, i.e., manifolds that admit a tessellation by regular ideal
    hyperbolic octahedra.
    """

    def __init__(self, **kwargs):
        return IsosigPlatonicManifoldTable.__init__(
            self,
            'octahedral_nonorientable_cusped_census',
            db_path = os.path.join(base_path, "octahedralNonorientableCuspedCensus.sqlite"),
            **kwargs)

class CubicalOrientableCuspedTable(IsosigPlatonicManifoldTable):
    """
    Iterator for the cubical orientable cusped hyperbolic manifolds up to
    7 cubes, i.e., manifolds that admit a tessellation by regular ideal
    hyperbolic octahedra.
    """

    def __init__(self, **kwargs):
        return IsosigPlatonicManifoldTable.__init__(
            self,
            'cubical_orientable_cusped_census',
            db_path = os.path.join(base_path, "cubicalOrientableCuspedCensus.sqlite"),
            **kwargs)

class CubicalNonorientableCuspedTable(IsosigPlatonicManifoldTable):
    """
    Iterator for the cubical non-orientable cusped hyperbolic manifolds up to
    5 cubes, i.e., manifolds that admit a tessellation by regular ideal
    hyperbolic octahedra.
    """

    def __init__(self, **kwargs):
        return IsosigPlatonicManifoldTable.__init__(
            self,
            'cubical_nonorientable_cusped_census',
            db_path = os.path.join(base_path, "cubicalNonorientableCuspedCensus.sqlite"),
            **kwargs)

class DodecahedralOrientableCuspedTable(IsosigPlatonicManifoldTable):
    """
    Iterator for the dodecahedral orientable cusped hyperbolic manifolds up to
    2 dodecahedra, i.e., manifolds that admit a tessellation by regular ideal
    hyperbolic dodecahedra.
    """

    def __init__(self, **kwargs):
        return IsosigPlatonicManifoldTable.__init__(
            self,
            'dodecahedral_orientable_cusped_census',
            db_path = os.path.join(base_path, "dodecahedralOrientableCuspedCensus.sqlite"),
            **kwargs)

class DodecahedralNonorientableCuspedTable(IsosigPlatonicManifoldTable):
    """
    Iterator for the dodecahedral non-orientable cusped hyperbolic manifolds up to
    2 dodecahedra, i.e., manifolds that admit a tessellation by regular ideal
    hyperbolic dodecahedra.
    """

    def __init__(self, **kwargs):
        return IsosigPlatonicManifoldTable.__init__(
            self,
            'dodecahedral_nonorientable_cusped_census',
            db_path = os.path.join(base_path, "dodecahedralNonorientableCuspedCensus.sqlite"),
            **kwargs)


class IcosahedralNonorientableClosedTable(IsosigPlatonicManifoldTable):
    """
    Iterator for the icosahedral non-orientable closed hyperbolic manifolds up
    to 3 icosahedra, i.e., manifolds that admit a tessellation by regular finite
    hyperbolic icosahedra.
    """

    def __init__(self, **kwargs):
        return IsosigPlatonicManifoldTable.__init__(
            self,
            'icosahedral_nonorientable_closed_census',
            db_path = os.path.join(base_path, "icosahedralNonorientableClosedCensus.sqlite"),
            **kwargs)

class IcosahedralOrientableClosedTable(IsosigPlatonicManifoldTable):
    """
    Iterator for the icosahedral orientable closed hyperbolic manifolds up
    to 4 icosahedra, i.e., manifolds that admit a tessellation by regula finite
    hyperbolic icosahedra.
    """

    def __init__(self, **kwargs):
        return IsosigPlatonicManifoldTable.__init__(
            self,
            'icosahedral_orientable_closed_census',
            db_path = os.path.join(base_path, "icosahedralOrientableClosedCensus.sqlite"),
            **kwargs)

class CubicalNonorientableClosedTable(IsosigPlatonicManifoldTable):
    """
    Iterator for the cubical non-orientable closed hyperbolic manifolds up
    to 10 cubes, i.e., manifolds that admit a tessellation by regular finite
    hyperbolic cubes.
    """

    def __init__(self, **kwargs):
        return IsosigPlatonicManifoldTable.__init__(
            self,
            'cubical_nonorientable_closed_census',
            db_path = os.path.join(base_path, "cubicalNonorientableClosedCensus.sqlite"),
            **kwargs)

class CubicalOrientableClosedTable(IsosigPlatonicManifoldTable):
    """
    Iterator for the cubical orientable closed hyperbolic manifolds up
    to 10 cubes, i.e., manifolds that admit a tessellation by regular finite
    hyperbolic cubes.
    """

    def __init__(self, **kwargs):
        return IsosigPlatonicManifoldTable.__init__(
            self,
            'cubical_orientable_closed_census',
            db_path = os.path.join(base_path, "cubicalOrientableClosedCensus.sqlite"),
            **kwargs)

class DodecahedralNonorientableClosedTable(IsosigPlatonicManifoldTable):
    """
    Iterator for the dodecahedral non-orientable closed hyperbolic manifolds up
    to 2 dodecahedra, i.e., manifolds that admit a tessellation by regular finite
    hyperbolic dodecahedra.
    """

    def __init__(self, **kwargs):
        return IsosigPlatonicManifoldTable.__init__(
            self,
            'dodecahedral_nonorientable_closed_census',
            db_path = os.path.join(base_path, "dodecahedralNonorientableClosedCensus.sqlite"),
            **kwargs)

class DodecahedralOrientableClosedTable(IsosigPlatonicManifoldTable):
    """
    Iterator for the dodecahedral orientable closed hyperbolic manifolds up
    to 3 dodecahedra, i.e., manifolds that admit a tessellation by regular finite
    hyperbolic dodecahedra.
    """

    def __init__(self, **kwargs):
        return IsosigPlatonicManifoldTable.__init__(
            self,
            'dodecahedral_orientable_closed_census',
            db_path = os.path.join(base_path, "dodecahedralOrientableClosedCensus.sqlite"),
            **kwargs)

TetrahedralOrientableCuspedCensus = TetrahedralOrientableCuspedTable()
TetrahedralNonorientableCuspedCensus = TetrahedralNonorientableCuspedTable()
OctahedralOrientableCuspedCensus = OctahedralOrientableCuspedTable()
OctahedralNonorientableCuspedCensus = OctahedralNonorientableCuspedTable()
CubicalOrientableCuspedCensus = CubicalOrientableCuspedTable()
CubicalNonorientableCuspedCensus = CubicalNonorientableCuspedTable()
DodecahedralOrientableCuspedCensus = DodecahedralOrientableCuspedTable()
DodecahedralNonorientableCuspedCensus = DodecahedralNonorientableCuspedTable()
IcosahedralNonorientableClosedCensus = IcosahedralNonorientableClosedTable()
IcosahedralOrientableClosedCensus = IcosahedralOrientableClosedTable()
CubicalNonorientableClosedCensus = CubicalNonorientableClosedTable()
CubicalOrientableClosedCensus = CubicalOrientableClosedTable()
DodecahedralNonorientableClosedCensus = DodecahedralNonorientableClosedTable()
DodecahedralOrientableClosedCensus = DodecahedralOrientableClosedTable()
