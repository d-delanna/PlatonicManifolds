#!/usr/bin/python

from snappy import Manifold
from regina import NTriangulation

from readDataFiles import parse_text

import sys, random

def get_geometric(name, isoSig):

    M = Manifold(isoSig)
    if 'positive' in M.solution_type():
        return M

    for i in range(100):
        N = NTriangulation.fromIsoSig(isoSig)
        for k in range(i):
            N.twoThreeMove(
                N.getTriangle(
                    random.randint(0, N.getNumberOfTriangles() - 1)))
            M = Manifold(N.isoSig())
            if 'positive' in M.solution_type():
                return M
            N2 = NTriangulation(N)
            N2.simplifyToLocalMinimum()
            M = Manifold(N2.isoSig())
            if 'positive' in M.solution_type():
                return M
        
    print >> sys.stderr, ("WARNING not geometric %s" % name)

    return M

if __name__ == '__main__':
    if not len(sys.argv) == 2:
        print >>sys.stderr, (
            "Usage: findGeometricForClosed.py NAMED_FILES")
        sys.exit(1)

    namedListOfListOfIsoSigs = parse_text(open(sys.argv[1]).read())

    for name, listOfIsoSigs, isometry_signature in namedListOfListOfIsoSigs:
        isoSig = listOfIsoSigs[0]
        mfd = get_geometric(name, isoSig)

        #print mfd, mfd.has_finite_vertices()
        #print mfd.cusp_info()

        print name,
        print mfd.triangulation_isosig(decorated=True),
        print isometry_signature
