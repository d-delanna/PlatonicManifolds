#!/usr/bin/python

from snappy import Manifold

import sys, os

def isometry_signature(iso_sig):
    """
    Compute the verified isometry signature of a manifold.
    Try several times if we fail.
    """

    M = Manifold(iso_sig)

    for i in range(10):

        for i in range(1000):
            if 'posi' in M.solution_type():
                break
            M.randomize()

        try:
            # We know that the degree of the shape field is at most 4
            # for Platonic manifolds.
            s = M.isometry_signature(
                verified=True,
                exact_bits_prec_and_degrees=[
                    (212, 5), (1000, 5), (2000, 5), (4000, 5), (8000, 5)])
            if s:
                return s
        except Exception as e:
            M.randomize()
            print >>sys.stderr, "Encountered exception: ", e

    raise Exception("Failed")

def get_output_file_name(addl, input_file_path):
    path, name = os.path.split(input_file_path)
    output_name = addl + name
    return os.path.join(path, output_name)

if __name__ == '__main__':
    if not len(sys.argv) == 2:
        print >>sys.stderr, (
            "Usage: python python/computeIsometrySignatures.py INPUT_FILE")
        sys.exit(1)

    input_file_name = sys.argv[1]
    output_file_name = get_output_file_name(
        'isometry_signatures_', input_file_name)

    # Read input file
    lines = open(input_file_name).read()

    # Input file has no groupings, so each line has exactly one entry,
    # get it.
    all_iso_sigs = [ isoSigs.strip()
                     for isoSigs in lines.split('\n')
                     if isoSigs.strip() ]

    # Output file
    output_file = open(output_file_name, 'w')

    # Iterate through isomorphism signatures write to file
    for i, iso_sig in enumerate(all_iso_sigs):
        output_file.write('%s %s\n' % (iso_sig, isometry_signature(iso_sig)))
        output_file.flush()

        print >>sys.stderr, "%d/%d" % (i+1, len(all_iso_sigs))

