#!/usr/bin/python

from snappy import Manifold
from snappy.db_utilities import cover_type

from readDataFiles import fake_isometry_signature_prefix

import sys, os

def cover_hash(mfld, degrees, t = 'all'):
    res = [ repr(sorted(
            [(cover_type(C), C.homology())
             for C in mfld.covers(degree,
                                  cover_type = t)]
            ))
            for degree in degrees ]
    return str(res).translate(None, " '\"")

def special_invariant(iso_sig):
    """
    Compute the fake isometry signature from the cover hash.
    """

    M = Manifold(iso_sig)
    degrees = (1,2,3)
    hash_str = cover_hash(M, degrees)

    if hash_str == '[[(cyc,Z/5+Z/5+Z/5)],[],[]]':
        print "Special 1"
        hash_str += cover_hash(M, (5,), 'cyclic')

    if hash_str == '[[(cyc,Z/29)],[],[]]':
        print "Special 2"
        hash_str += cover_hash(M, (6,))

    if hash_str == '[[(cyc,Z+Z)],[(cyc,Z+Z+Z),(cyc,Z+Z+Z),(cyc,Z+Z+Z)],[(cyc,Z+Z+Z+Z),(cyc,Z+Z+Z+Z),(cyc,Z+Z+Z+Z),(cyc,Z/2+Z/2+Z/2+Z/2+Z+Z+Z+Z),(irr,Z+Z+Z+Z),(irr,Z+Z+Z+Z),(irr,Z+Z+Z+Z)]]':
        print "Special 3"
        hash_str += cover_hash(M, (6,), 'cyclic')

    if hash_str == '[[(cyc,Z/6+Z/18+Z)],[(cyc,Z/3+Z/3+Z/36+Z/36+Z),(cyc,Z/3+Z/36+Z),(cyc,Z/3+Z/36+Z),(cyc,Z/3+Z/36+Z),(cyc,Z/3+Z/36+Z),(cyc,Z/3+Z/36+Z),(cyc,Z/3+Z/36+Z)],[(cyc,Z/3+Z/3+Z/6+Z/6+Z+Z+Z),(cyc,Z/3+Z/3+Z/6+Z/18+Z/18+Z/18+Z),(cyc,Z/3+Z/3+Z/18+Z/54+Z),(cyc,Z/3+Z/3+Z/18+Z/54+Z),(cyc,Z/3+Z/3+Z/18+Z/54+Z),(cyc,Z/3+Z/3+Z/18+Z/54+Z),(cyc,Z/3+Z/3+Z/18+Z/54+Z),(cyc,Z/3+Z/3+Z/18+Z/54+Z),(cyc,Z/3+Z/3+Z/18+Z/54+Z),(cyc,Z/3+Z/3+Z/18+Z/54+Z),(cyc,Z/3+Z/3+Z/18+Z/54+Z),(cyc,Z/6+Z/6+Z/6+Z/6+Z+Z+Z),(cyc,Z/6+Z/6+Z/6+Z/6+Z+Z+Z),(irr,Z/2+Z/6+Z+Z+Z+Z+Z),(irr,Z/3+Z/3+Z/6+Z/6+Z+Z+Z),(irr,Z/3+Z/3+Z/9+Z/18+Z/54+Z),(irr,Z/3+Z/6+Z/18+Z+Z+Z)]]':
        print "Special 4"
        hash_str += cover_hash(M, (18,), 'cyclic')

    if hash_str == '[[(cyc,Z/4+Z/4+Z)],[(cyc,Z/2+Z/2+Z+Z+Z),(cyc,Z/2+Z/2+Z/8+Z/8+Z),(cyc,Z/2+Z/4+Z/4+Z/4+Z),(cyc,Z/2+Z/4+Z/4+Z/4+Z),(cyc,Z/2+Z/4+Z/4+Z/4+Z),(cyc,Z/2+Z/4+Z/4+Z/4+Z),(cyc,Z/4+Z/4+Z/4+Z/4+Z)],[(cyc,Z/2+Z/2+Z/2+Z/2+Z/4+Z/4+Z),(irr,Z/2+Z/2+Z/2+Z/2+Z/4+Z/4+Z),(irr,Z/2+Z/2+Z/2+Z/2+Z/4+Z/4+Z),(irr,Z/2+Z/2+Z/4+Z/4+Z),(irr,Z/2+Z/2+Z/4+Z/4+Z)]]':
        print "Special 5"
        hash_str += cover_hash(M, (4,))

    if hash_str == '[[(cyc,Z/4+Z/4+Z/8)],[(cyc,Z/2+Z/2+Z/4+Z/16+Z/16),(cyc,Z/2+Z/2+Z/8+Z/8+Z),(cyc,Z/2+Z/4+Z/4+Z/4+Z),(cyc,Z/2+Z/4+Z/4+Z/4+Z),(cyc,Z/2+Z/4+Z/4+Z/8+Z/8),(cyc,Z/2+Z/4+Z/4+Z/8+Z/8),(cyc,Z/4+Z/4+Z/4+Z/4+Z/4)],[(irr,Z/2+Z/2+Z/2+Z/2+Z/4+Z/4+Z/8),(irr,Z/2+Z/2+Z/2+Z/2+Z/4+Z/4+Z/8),(irr,Z/2+Z/2+Z/2+Z/2+Z/4+Z/4+Z/8)]]':
        print "Special 6"
        hash_str += cover_hash(M, (4,))

    if hash_str == '[[(cyc,Z/2+Z/4+Z/4+Z)],[(cyc,Z/2+Z/2+Z+Z+Z+Z),(cyc,Z/2+Z/2+Z+Z+Z+Z),(cyc,Z/2+Z/2+Z/2+Z/2+Z/2+Z/8+Z),(cyc,Z/2+Z/2+Z/2+Z/2+Z/2+Z/8+Z),(cyc,Z/2+Z/2+Z/2+Z/2+Z/4+Z+Z),(cyc,Z/2+Z/2+Z/2+Z/2+Z/4+Z+Z),(cyc,Z/2+Z/2+Z/2+Z/2+Z/4+Z/4+Z),(cyc,Z/2+Z/2+Z/2+Z/2+Z/4+Z/4+Z),(cyc,Z/2+Z/2+Z/2+Z/2+Z/4+Z/4+Z),(cyc,Z/2+Z/2+Z/4+Z+Z+Z),(cyc,Z/2+Z/2+Z/4+Z+Z+Z),(cyc,Z/2+Z/2+Z/4+Z+Z+Z),(cyc,Z/2+Z/2+Z/4+Z+Z+Z),(cyc,Z/2+Z/4+Z/4+Z/4+Z+Z),(cyc,Z/2+Z/4+Z/4+Z/4+Z+Z)],[(cyc,Z/2+Z/2+Z/2+Z/2+Z/2+Z/2+Z/2+Z/4+Z/4+Z),(irr,Z/2+Z/2+Z/2+Z/2+Z/2+Z/2+Z/2+Z/4+Z/4+Z),(irr,Z/2+Z/2+Z/2+Z/4+Z/4+Z/4+Z/4+Z),(irr,Z/2+Z/2+Z/4+Z/4+Z+Z+Z),(irr,Z/2+Z/2+Z/4+Z/4+Z+Z+Z),(irr,Z/2+Z/2+Z/4+Z/4+Z+Z+Z),(irr,Z/2+Z/2+Z/4+Z/4+Z+Z+Z),(irr,Z/2+Z/2+Z/4+Z/4+Z+Z+Z),(irr,Z/2+Z/2+Z/4+Z/4+Z+Z+Z),(irr,Z/2+Z/4+Z/4+Z+Z),(irr,Z/2+Z/4+Z/4+Z+Z),(irr,Z/2+Z/4+Z/4+Z+Z),(irr,Z/2+Z/4+Z/4+Z+Z),(irr,Z/2+Z/4+Z/4+Z+Z),(irr,Z/2+Z/4+Z/4+Z+Z),(irr,Z/2+Z/4+Z/4+Z+Z),(irr,Z/2+Z/4+Z/4+Z+Z),(irr,Z/2+Z/4+Z/4+Z+Z),(irr,Z/2+Z/4+Z/4+Z+Z),(irr,Z/2+Z/4+Z/4+Z/4+Z+Z+Z),(irr,Z/2+Z/4+Z/4+Z/4+Z+Z+Z),(irr,Z/2+Z/4+Z/4+Z/4+Z/4+Z+Z),(irr,Z/2+Z/4+Z/4+Z/4+Z/4+Z+Z),(irr,Z/2+Z/4+Z/4+Z/4+Z/4+Z+Z),(irr,Z/2+Z/4+Z/4+Z/4+Z/4+Z+Z),(irr,Z/2+Z/4+Z/12+Z+Z),(irr,Z/2+Z/4+Z/12+Z+Z),(irr,Z/2+Z/4+Z/12+Z+Z),(irr,Z/2+Z/4+Z/12+Z+Z),(irr,Z/2+Z/4+Z/12+Z+Z),(irr,Z/2+Z/4+Z/12+Z+Z),(irr,Z/2+Z/4+Z/12+Z+Z),(irr,Z/2+Z/4+Z/12+Z+Z),(irr,Z/2+Z/4+Z/12+Z+Z),(irr,Z/2+Z/4+Z/12+Z+Z),(irr,Z/2+Z/4+Z/12+Z+Z),(irr,Z/2+Z/4+Z/12+Z+Z),(irr,Z/2+Z/4+Z/12+Z+Z),(irr,Z/2+Z/4+Z/12+Z+Z),(irr,Z/2+Z/4+Z/12+Z+Z),(irr,Z/2+Z/4+Z/12+Z+Z),(irr,Z/2+Z/4+Z/12+Z+Z),(irr,Z/2+Z/4+Z/12+Z+Z),(irr,Z/2+Z/4+Z/12+Z+Z),(irr,Z/2+Z/4+Z/12+Z+Z),(irr,Z/2+Z/12+Z/12+Z+Z),(irr,Z/2+Z/12+Z/12+Z+Z)]]':
        print "Special 7"
        hash_str += cover_hash(M, (4,))
        

    return fake_isometry_signature_prefix + hash_str

def get_output_file_name(addl, input_file_path):
    path, name = os.path.split(input_file_path)
    output_name = addl + name
    return os.path.join(path, output_name)

if __name__ == '__main__':
    if not len(sys.argv) == 2:
        print >>sys.stderr, (
            "Usage: python "
            "python/computeInvariantForClosedManifolds.py "
            "INPUT_FILE")
        sys.exit(1)

    input_file_name = sys.argv[1]
    output_file_name = get_output_file_name(
        'special_invariants_', input_file_name)

    # Read input file
    lines = open(input_file_name).read()

    # Input file has no groupings, so each line has exactly one entry,
    # get it.
    all_iso_sigs = [ isoSigs.strip()
                     for isoSigs in lines.split('\n')
                     if isoSigs.strip() ]

    # Output file
    output_file = open(output_file_name, 'w')

    # Iterate through isomorphism signatures write to file
    for i, iso_sig in enumerate(all_iso_sigs):
        output_file.write('%s %s\n' % (iso_sig, special_invariant(iso_sig)))
        output_file.flush()

        print >>sys.stderr, "%d/%d" % (i+1, len(all_iso_sigs))

