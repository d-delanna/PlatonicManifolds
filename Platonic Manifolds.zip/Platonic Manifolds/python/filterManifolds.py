#!/usr/bin/python

from regina import NTriangulation

import sys

def is_manifold(trig):
    # The good cases are:
    # * finite vertex with spherical link
    #   Euler characteristic 2
    # * Ideal vertex with Klein bottle or torus link
    #   Euler characteristic 0
    # The base case is:
    #   Projective plane with characteristic 1

    for v in trig.getVertices():
        if not v.getLinkEulerChar() in [0, 2]:
            return False
    return True

if __name__ == '__main__':

    for line in open(sys.argv[1]).read().split('\n'):
        if line:
            trig = NTriangulation.fromIsoSig(line)
            if is_manifold(trig):
                print line
