#!/usr/bin/python

import sys

# Regina's Base64 encoding scheme
base64_str = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+-'

def sval(c):
    """
    Decode one character of Regina's isomorphism signature
    """
    return base64_str.index(c)

def sread(s):
    """
    Decode a string of characters from Regina's isomorphism signature
    """
    return sum([sval(c) * 64 ** i for i, c in enumerate(s)])

def isoSigComponentSize(s):
    """
    Get the number of tetrahedra from Regina's isomorphism signature
    """
    
    first_char = sval(s[0])
    if first_char < 63:
        return first_char

    second_char = sval(s[1])
    return sread(s[2:2+second_char])

def find_isometric(all_isomorphism_isometry_sig_pairs):
    """
    Group into a list of lists of isomorphism signatures of
    isometric triangulations.
    """

    # Dictionary: isometry signature |-> isomorphism signatures
    # Each value will be a list of isomorpism signatures of isometric
    # triangulations
    d = {}
    for iso_sig, isometry_sig in all_isomorphism_isometry_sig_pairs:
        # Add to iso sig to dict
        d.setdefault(isometry_sig,[]).append(iso_sig)

    # Sort all isomorphism signatures
    list_of_list_of_iso_sigs = [ sorted(iso_sigs) + [ isometry_sig ]
                                 for isometry_sig, iso_sigs in d.items() ]
    
    def key_function(list_of_iso_sigs):
        representative = list_of_iso_sigs[0]
        return (isoSigComponentSize(representative), representative)

    return sorted(list_of_list_of_iso_sigs, key = key_function)

# Turn a list of list of isomorphism signatures into a list of pairs
# (name, list of isomorphism signatures)
# name is generated from a template that is given two integers
# The first integer is the number of tetrahedra
# The next integer is an index that is per number of tetrahedra
def gen_names(listOfListOfIsoSigs, template, simplices_per_solid):

    # Current index for a particular number of tetrahedra
    # Hard coded to at most 99 solids
    indicies = [ 0 for i in range(100) ]

    result = []

    # Iterate through input
    for listOfIsoSigs in listOfListOfIsoSigs:
        # Pick first iso sig as representative
        representative = listOfIsoSigs[0]
        # Get the number of tetrahedra
        num_simplices = isoSigComponentSize(representative)

        if not num_simplices % simplices_per_solid == 0:
            print >>sys.stderr, ("Fatal error: number of simplices %d not a "
                                 "multiple of %d." % (num_simplices,
                                                      simplices_per_solid))
            sys.exit(1)

        num_solids = num_simplices / simplices_per_solid
            
        # Create the name using number of tetrahedra and index
        name = template % (num_solids, indicies[num_solids])
        result.append([name] + listOfIsoSigs)

        # Increment index
        indicies[num_solids] += 1

    return result

def output_list_of_list(list_of_list):
    """
    Output homeomorphic isomorphism signatures on the same line.
    """

    for l in list_of_list:
        print ' '.join(l)

if __name__ == '__main__':
    if not len(sys.argv) == 4 or not sys.argv[1] in ['tet', 'oct', 'cube', 'dode', 'ico']:
        print >>sys.stderr, (
            "Usage: python "
            "groupAndNameIsometricIsomoSigsOfPlatonicTessellations.py "
            "tet|oct|cube|dode|ico "
            "INPUT_FILE NAMING_TEMPLATE")
        sys.exit(1)

    # Parse command line
    solid, input_file, template = sys.argv[1:]

    # Find out how many simplices form a solid
    simplices_per_solid_dict = {
        'tet' : 2 * 3 * 4,
        'oct' : 2 * 3 * 8,
        'cube' : 2 * 4 * 6,
        'dode' : 2 * 5 * 12,
        'ico' : 2 * 3 * 20,
        }
    simplices_per_solid = simplices_per_solid_dict[solid]

    # Read input file
    lines = open(input_file).read()

    # Input file has no groupings, so each line has exactly one entry,
    # get it.
    all_isomorphism_isometry_sig_pairs = [
        line.strip().split() for line in lines.split('\n') if line.strip()]

    # Group by isometry signatures
    list_of_list_of_iso_sigs = find_isometric(
        all_isomorphism_isometry_sig_pairs)

    # Name
    named_list_of_list_of_iso_sigs = gen_names(
        list_of_list_of_iso_sigs, template, simplices_per_solid)

    # Output
    output_list_of_list(named_list_of_list_of_iso_sigs)

