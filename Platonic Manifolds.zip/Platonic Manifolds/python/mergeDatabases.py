import sqlite3, os, sys

schema = """
CREATE TABLE %s (
  id integer primary key,
  name text,
  cusps int,
  betti int,
  tets int,
  solids int,
  hash blob,
  volume real,
  triangulation text)
"""

insert_query = """
insert into %s
     (name, cusps, betti, tets, solids, hash, volume, triangulation)
select
      name, cusps, betti, tets, solids, hash, volume, triangulation
from inputDB.%s;
"""

def createTable(connection, tableName):
    connection.execute(schema % tableName)
    connection.commit()


def merge_into(connection, tableName, inputDB):
    connection.execute("attach '%s' as inputDB" % inputDB)
    connection.execute(insert_query % (tableName, tableName))
    connection.commit()
    connection.execute("detach inputDB")

if __name__ == '__main__':
    if not len(sys.argv) >= 4:
        print >> sys.stderr, (
            "Usage: mergeDatabases.py TABLE_NAME DB_FILE "
            "DB_FILE_IN1 DB_FILE_IN2 ...")
        sys.exit(1)

    tableName, dbFile = sys.argv[1:3]
    dbInFiles = sys.argv[3:]

    if os.path.exists(dbFile):
        os.remove(dbFile)

    connection = sqlite3.connect(dbFile)
    
    createTable(connection, tableName)
    
    for dbInFile in dbInFiles:
        merge_into(connection, tableName, dbInFile)

    connection.close()

