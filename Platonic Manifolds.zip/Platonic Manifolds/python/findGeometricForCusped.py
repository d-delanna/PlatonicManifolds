#!/usr/bin/python

from snappy import Manifold

from readDataFiles import parse_text

import sys

def get_geometric(name, isoSig):

    for j in range(100):
        M = Manifold(isoSig)
    
        for i in range(100):
            if 'positive' in M.solution_type():
                return M
            M.randomize()

        if 'positive' in M.solution_type():
            return M

    print >> sys.stderr, ("WARNING not geometric %s" % name)

    return M

if __name__ == '__main__':
    if not len(sys.argv) == 3:
        print >>sys.stderr, (
            "Usage: findGeometricForCusped.py NAMED_FILE OUTPUT_FILE")
        sys.exit(1)

    namedListOfListOfIsoSigs = parse_text(open(sys.argv[1]).read())

    out = open(sys.argv[2],'w')

    for name, listOfIsoSigs, isometry_signature in namedListOfListOfIsoSigs:
        isoSig = listOfIsoSigs[0]
        mfd = get_geometric(name, isoSig)

        #print mfd, mfd.has_finite_vertices()
        #print mfd.cusp_info()

        out.write("%s %s %s\n" % (
                name, mfd.triangulation_isosig(), isometry_signature))

    out.close()


