#!/usr/bin/python

# Generates a regina file from a file of isomorphism signatures

from readDataFiles import (parse_text, get_solid_and_number,
                           fake_isometry_signature_prefix)

from regina import NTriangulation, NContainer

import os, sys

if __name__ == '__main__':
    # Check proper usage
    if not len(sys.argv) == 4:
        print >>sys.stderr, (
            "Usage: genReginaCensusFiles INPUT_FILE ROOT_ITEM_LABEL REGINA_FILE")
        sys.exit(1)

    # Parse command line
    inputFile, rootItemName, rgaFile = sys.argv[1:]

    # Read in file of isomorphism signatures
    namedListOfListOfIsoSigs = parse_text(open(inputFile).read())
    
    # Determine the number of tetrahedra occuring
    numbers_of_solids = set()
    solids = set()
    for name, listOfIsoSigs, isometry_signature in namedListOfListOfIsoSigs:
        representative = listOfIsoSigs[0]
        solid, number_of_solids = get_solid_and_number(name)
        solids.add(solid)
        numbers_of_solids.add(number_of_solids)

    if not len(solids) == 1:
        raise Exception("Not all the same solid")

    # Create root items
    rootItem = NContainer()
    rootItem.setPacketLabel(rootItemName)

    # Create a container for each number of tetrahedra
    tet_items = {}
    for number_of_solids in sorted(numbers_of_solids):
        tet_items[number_of_solids] = NContainer()
    
    # Iterate through the named lists of isomorphism signatures
    for name, listOfIsoSigs, isometry_signature in namedListOfListOfIsoSigs:

        # Create container for manifold
        manifold_item = NContainer()
        manifold_item.setPacketLabel(name)
        representative = listOfIsoSigs[0]
        number_of_solids = get_solid_and_number(name)[1]

        for i, isoSig in enumerate(listOfIsoSigs):
            # Create triangulations for each isomorphism signature
            tessellation_item = NTriangulation.fromIsoSig(isoSig)
            tessellation_item.setPacketLabel('%s#%d' % (name, i))

            manifold_item.insertChildLast(tessellation_item)

        if not fake_isometry_signature_prefix in isometry_signature:
            canon_item = NTriangulation.fromIsoSig(isometry_signature)
            canon_item.setPacketLabel('%s#Canonical' % name)
            manifold_item.insertChildLast(canon_item)

        tet_items[number_of_solids].insertChildLast(manifold_item)

    solid = list(solids)[0]

    # Now put it all together
    for number_of_solids in sorted(numbers_of_solids):
        tet_items[number_of_solids].setPacketLabel(
            '%d %s' % (number_of_solids, solid))
        rootItem.insertChildLast(tet_items[number_of_solids])

    # And save
    rootItem.save(rgaFile)
