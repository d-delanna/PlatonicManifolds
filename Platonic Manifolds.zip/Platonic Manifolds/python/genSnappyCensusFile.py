#!/usr/bin/python

from readDataFiles import parse_text, get_solid_and_number

from snappy.db_utilities import db_hash
from snappy import Manifold

import sqlite3, binascii, os, sys

schema = """
CREATE TABLE %s (
  id integer primary key,
  name text,
  cusps int,
  betti int,
  tets int,
  solids int,
  hash blob,
  volume real,
  triangulation text)
"""

insert_query = """insert into %s
(name, cusps, betti, tets, solids, hash, volume, triangulation)
values ('%s', %d, %d, %d, %d, X'%s', %s, '%s')"""

def createTable(connection, tableName):
    connection.execute(schema % tableName)
    connection.commit()
    
def insertIsomSig(connection, tableName, isoSig, name):

    mfld = Manifold(isoSig)
    mfld.set_name(name)
    cusps = mfld.num_cusps()
    betti = mfld.homology().betti_number()
    tets = mfld.num_tetrahedra()
    hash = db_hash(mfld)
    volume = mfld.volume()
    #trig = '40' + binascii.hexlify(mfld._to_string())
#    trig = (
#        '%02x' % cusps + (4 * cusps) * '00' +
#        binascii.hexlify(mfld._to_bytes()))

    # trig = mfld.triangulation_isosig()

    solids = get_solid_and_number(name)[1]

    connection.execute(
        insert_query % (tableName,
            name, cusps, betti, tets, solids, hash, volume, isoSig))
    connection.commit()

if __name__ == '__main__':
    if not len(sys.argv) == 4:
        print >>sys.stderr, (
            "Usage: genSnappyCensusFiles.py INPUT_FILE TABLE_NAME DB_FILE")
        sys.exit(1)

    inputFile, tableName, dbFile = sys.argv[1:]

    if os.path.exists(dbFile):
        os.remove(dbFile)

    connection = sqlite3.connect(dbFile)

    createTable(connection, tableName)

    namedListOfListOfIsoSigs = parse_text(open(inputFile).read())

    for name, listOfIsoSigs, isometry_signature in namedListOfListOfIsoSigs:
        print >>sys.stderr, ".",
        insertIsomSig(connection, tableName, listOfIsoSigs[0], name)

    connection.close()

    print >>sys.stderr

