#!/usr/bin/python

from readDataFiles import parse_text

from snappy import Manifold

import sys

def are_isometric(a, aIsoSig, b, bIsoSig):
    for i in range(10):
        try:
            return a.is_isometric_to(b)
        except RuntimeError:
            a = Manifold(aIsoSig)
            b = Manifold(bIsoSig)

    return a.is_isometric_to(b)


def check_isometric(name, listOfIsoSigs):
    first = Manifold(listOfIsoSigs[0])
    for isoSig in listOfIsoSigs[1:]:
        mfd = Manifold(isoSig)
        print "Testing %s: comparing %s and %s"  % (
            name, listOfIsoSigs[0], isoSig)
        if not are_isometric(first, listOfIsoSigs[0], mfd, isoSig):
            print >>sys.stderr, "is_isometric_to is FALSE"
            print >>sys.stderr, "FAILED!!!!!!!!!!!!!!!!!!"
            sys.exit(1)

if __name__ == '__main__':
    if not len(sys.argv) == 2:
        print >>sys.stderr, (
            "Usage: checkFakeIsometrySignaturesStrongEnough.py INPUT_FILE")

    inputFile = sys.argv[1]
    namedListOfListOfIsoSigs = parse_text(open(inputFile).read())

    for name, listOfIsoSigs, isometry_signature in namedListOfListOfIsoSigs:
        print name
        check_isometric(name, listOfIsoSigs)
