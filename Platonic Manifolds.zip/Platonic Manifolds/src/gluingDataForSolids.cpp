#include "gluingDataForSolids.h"

#include <iostream>

// Tetrahedron

static const GluingTriple _gluingDataForTetrahedron[] = {
    {   5,   1,  23},    //   0
    {   2,   0,   6},    //   1
    {   1,   3,  11},    //   2
    {   4,   2,  16},    //   3
    {   3,   5,  15},    //   4
    {   0,   4,  18},    //   5
    {  11,   7,   1},    //   6
    {   8,   6,  22},    //   7
    {   7,   9,  21},    //   8
    {  10,   8,  12},    //   9
    {   9,  11,  17},    //  10
    {   6,  10,   2},    //  11
    {  17,  13,   9},    //  12
    {  14,  12,  20},    //  13
    {  13,  15,  19},    //  14
    {  16,  14,   4},    //  15
    {  15,  17,   3},    //  16
    {  12,  16,  10},    //  17
    {  23,  19,   5},    //  18
    {  20,  18,  14},    //  19
    {  19,  21,  13},    //  20
    {  22,  20,   8},    //  21
    {  21,  23,   7},    //  22
    {  18,  22,   0},    //  23
    {  -1,  -1,  -1}     //  Indicate the end
};

// Octahedron

static const GluingTriple _gluingDataForOctahedron[] = {
    {   5,   1,  11},    //   0
    {   2,   0,  12},    //   1
    {   1,   3,  17},    //   2
    {   4,   2,  18},    //   3
    {   3,   5,  23},    //   4
    {   0,   4,   6},    //   5
    {  11,   7,   5},    //   6
    {   8,   6,  36},    //   7
    {   7,   9,  41},    //   8
    {  10,   8,  24},    //   9
    {   9,  11,  29},    //  10
    {   6,  10,   0},    //  11
    {  17,  13,   1},    //  12
    {  14,  12,  28},    //  13
    {  13,  15,  27},    //  14
    {  16,  14,  30},    //  15
    {  15,  17,  35},    //  16
    {  12,  16,   2},    //  17
    {  23,  19,   3},    //  18
    {  20,  18,  34},    //  19
    {  19,  21,  33},    //  20
    {  22,  20,  38},    //  21
    {  21,  23,  37},    //  22
    {  18,  22,   4},    //  23
    {  29,  25,   9},    //  24
    {  26,  24,  42},    //  25
    {  25,  27,  47},    //  26
    {  28,  26,  14},    //  27
    {  27,  29,  13},    //  28
    {  24,  28,  10},    //  29
    {  35,  31,  15},    //  30
    {  32,  30,  46},    //  31
    {  31,  33,  45},    //  32
    {  34,  32,  20},    //  33
    {  33,  35,  19},    //  34
    {  30,  34,  16},    //  35
    {  41,  37,   7},    //  36
    {  38,  36,  22},    //  37
    {  37,  39,  21},    //  38
    {  40,  38,  44},    //  39
    {  39,  41,  43},    //  40
    {  36,  40,   8},    //  41
    {  47,  43,  25},    //  42
    {  44,  42,  40},    //  43
    {  43,  45,  39},    //  44
    {  46,  44,  32},    //  45
    {  45,  47,  31},    //  46
    {  42,  46,  26},    //  47
    {  -1,  -1,  -1}     //  Indicate the end
};

// Dodecahedron

static const GluingTriple _gluingDataForDodecahedron[] = {
    {   9,   1,  59},    //   0
    {   2,   0,  10},    //   1
    {   1,   3,  19},    //   2
    {   4,   2,  20},    //   3
    {   3,   5,  29},    //   4
    {   6,   4,  30},    //   5
    {   5,   7,  39},    //   6
    {   8,   6,  40},    //   7
    {   7,   9,  49},    //   8
    {   0,   8,  50},    //   9
    {  19,  11,   1},    //  10
    {  12,  10,  58},    //  11
    {  11,  13,  57},    //  12
    {  14,  12, 108},    //  13
    {  13,  15, 107},    //  14
    {  16,  14,  60},    //  15
    {  15,  17,  69},    //  16
    {  18,  16,  22},    //  17
    {  17,  19,  21},    //  18
    {  10,  18,   2},    //  19
    {  29,  21,   3},    //  20
    {  22,  20,  18},    //  21
    {  21,  23,  17},    //  22
    {  24,  22,  68},    //  23
    {  23,  25,  67},    //  24
    {  26,  24,  70},    //  25
    {  25,  27,  79},    //  26
    {  28,  26,  32},    //  27
    {  27,  29,  31},    //  28
    {  20,  28,   4},    //  29
    {  39,  31,   5},    //  30
    {  32,  30,  28},    //  31
    {  31,  33,  27},    //  32
    {  34,  32,  78},    //  33
    {  33,  35,  77},    //  34
    {  36,  34,  80},    //  35
    {  35,  37,  89},    //  36
    {  38,  36,  42},    //  37
    {  37,  39,  41},    //  38
    {  30,  38,   6},    //  39
    {  49,  41,   7},    //  40
    {  42,  40,  38},    //  41
    {  41,  43,  37},    //  42
    {  44,  42,  88},    //  43
    {  43,  45,  87},    //  44
    {  46,  44,  90},    //  45
    {  45,  47,  99},    //  46
    {  48,  46,  52},    //  47
    {  47,  49,  51},    //  48
    {  40,  48,   8},    //  49
    {  59,  51,   9},    //  50
    {  52,  50,  48},    //  51
    {  51,  53,  47},    //  52
    {  54,  52,  98},    //  53
    {  53,  55,  97},    //  54
    {  56,  54, 100},    //  55
    {  55,  57, 109},    //  56
    {  58,  56,  12},    //  57
    {  57,  59,  11},    //  58
    {  50,  58,   0},    //  59
    {  69,  61,  15},    //  60
    {  62,  60, 106},    //  61
    {  61,  63, 105},    //  62
    {  64,  62, 110},    //  63
    {  63,  65, 119},    //  64
    {  66,  64,  72},    //  65
    {  65,  67,  71},    //  66
    {  68,  66,  24},    //  67
    {  67,  69,  23},    //  68
    {  60,  68,  16},    //  69
    {  79,  71,  25},    //  70
    {  72,  70,  66},    //  71
    {  71,  73,  65},    //  72
    {  74,  72, 118},    //  73
    {  73,  75, 117},    //  74
    {  76,  74,  82},    //  75
    {  75,  77,  81},    //  76
    {  78,  76,  34},    //  77
    {  77,  79,  33},    //  78
    {  70,  78,  26},    //  79
    {  89,  81,  35},    //  80
    {  82,  80,  76},    //  81
    {  81,  83,  75},    //  82
    {  84,  82, 116},    //  83
    {  83,  85, 115},    //  84
    {  86,  84,  92},    //  85
    {  85,  87,  91},    //  86
    {  88,  86,  44},    //  87
    {  87,  89,  43},    //  88
    {  80,  88,  36},    //  89
    {  99,  91,  45},    //  90
    {  92,  90,  86},    //  91
    {  91,  93,  85},    //  92
    {  94,  92, 114},    //  93
    {  93,  95, 113},    //  94
    {  96,  94, 102},    //  95
    {  95,  97, 101},    //  96
    {  98,  96,  54},    //  97
    {  97,  99,  53},    //  98
    {  90,  98,  46},    //  99
    { 109, 101,  55},    // 100
    { 102, 100,  96},    // 101
    { 101, 103,  95},    // 102
    { 104, 102, 112},    // 103
    { 103, 105, 111},    // 104
    { 106, 104,  62},    // 105
    { 105, 107,  61},    // 106
    { 108, 106,  14},    // 107
    { 107, 109,  13},    // 108
    { 100, 108,  56},    // 109
    { 119, 111,  63},    // 110
    { 112, 110, 104},    // 111
    { 111, 113, 103},    // 112
    { 114, 112,  94},    // 113
    { 113, 115,  93},    // 114
    { 116, 114,  84},    // 115
    { 115, 117,  83},    // 116
    { 118, 116,  74},    // 117
    { 117, 119,  73},    // 118
    { 110, 118,  64},    // 119
    {  -1,  -1,  -1}     //  Indicate the end
};

// Cube as dual of ocathedron

static GluingTriple* _gluingDataForCube = 0;

static void _initializeCube()
{
    if (_gluingDataForCube) {
	return;
    }

    const int num = sizeof(_gluingDataForOctahedron) / sizeof(GluingTriple);

    GluingTriple* gluingDataForCube = new GluingTriple[num];

    for (int i = 0; i < num; i++) {
	for (int j = 0; j < 3; j++) {
	    gluingDataForCube[i].values[j] =
		_gluingDataForOctahedron[i].values[2-j];
	}
    }

    _gluingDataForCube = gluingDataForCube;
}

// Icosahedron as dual of dodecahedron

static GluingTriple* _gluingDataForIcosahedron = 0;


static void _initializeIcosahedron()
{
    if (_gluingDataForIcosahedron) {
	return;
    }

    const int num = sizeof(_gluingDataForDodecahedron) / sizeof(GluingTriple);

    GluingTriple* gluingDataForIcosahedron = new GluingTriple[num];

    for (int i = 0; i < num; i++) {
	for (int j = 0; j < 3; j++) {
	    gluingDataForIcosahedron[i].values[j] =
		_gluingDataForDodecahedron[i].values[2-j];
	}
    }

    _gluingDataForIcosahedron = gluingDataForIcosahedron;
}

const GluingTriple* getGluingDataForSolid(int p, int q)
{
    if ((p == 3) and (q == 3)) {
	return &_gluingDataForTetrahedron[0];
    }

    if ((p == 3) and (q == 4)) {
	return &_gluingDataForOctahedron[0];
    }

    if ((p == 3) and (q == 5)) {
	_initializeIcosahedron();
	return _gluingDataForIcosahedron;
    }

    if ((p == 4) and (q == 3)) {
	_initializeCube();
	return _gluingDataForCube;
    }

    if ((p == 5) and (q == 3)) {
	return &_gluingDataForDodecahedron[0];
    }

    return NULL;
}

int test_main(int argc, char** argv)
{
  for (int i = 0; i < 120; i++) {
    for (int j = 0; j < 3; j++) {

      if (_gluingDataForDodecahedron[i].values[j] % 2 == i % 2) {
	std::cout << "WRONG!" << i << " " << j << std::endl;
      }

    }

  }

    for (int i = 0; i < 120; i++) {
	for (int j = 0; j < 3; j++) {
	    if (_gluingDataForDodecahedron[_gluingDataForDodecahedron[i].values[j]].values[j] != i) {
		std::cout << "WRONG " << i << " " << j << std::endl;
	    }
	}
    }

    for (int i = 0; i < 110; i++) {
	for (int j = 0; j < 2; j++) {

	    if (_gluingDataForDodecahedron[i % 10].values[j] % 10 != _gluingDataForDodecahedron[i].values[j] % 10) {
		std::cout << "WRONG2 " << i << " " << j << std::endl;
	    }

	}
    }

    for (int i = 0; i < 120; i++) {
	int k = i;

	for (int j = 0; j < 10; j++) {
	    k = _gluingDataForDodecahedron[k].values[j % 2];
	    
	    if (k == i and j != 9) {
		std::cout << "WRONG 01 " << i << " " << j << std::endl;
	    }
	    
	    if (k != i and j == 9) {
		std::cout << "WRONG 01b " << i << " " << j << std::endl;
	    }
	} 
    }

    for (int i = 0; i < 120; i++) {
	int k = i;

//	std::cout << std::endl;

	for (int j = 0; j < 6; j++) {
	    k = _gluingDataForDodecahedron[k].values[(j % 2) + 1];
	    
//	    std::cout << k << std::endl;

	    if (k == i and j != 5) {
		std::cout << "WRONG 12 " << i << " " << j << std::endl;
	    }
	    
	    if (k != i and j == 5) {
		std::cout << "WRONG 12b " << i << " " << j << std::endl;
	    }
	} 
    }

    for (int i = 0; i < 120; i++) {
	int k = i;

//	std::cout << std::endl;

	for (int j = 0; j < 4; j++) {
	    k = _gluingDataForDodecahedron[k].values[2 * (j % 2)];
	    
//	    std::cout << k << std::endl;

	    if (k == i and j != 3) {
		std::cout << "WRONG 02 " << i << " " << j << std::endl;
	    }
	    
	    if (k != i and j == 3) {
		std::cout << "WRONG 02b " << i << " " << j << std::endl;
	    }
	} 
    }


    std::cout << "Ran" << std::endl;

    return 0;
}
