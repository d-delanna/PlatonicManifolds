#include "platonicTessellationContext.h"
#include "gluingDataForSolids.h"

#include <iostream>

#include <unistd.h>

PlatonicTessellationContext::PlatonicTessellationContext(
    bool orientable, int p, int q, int r, int numSolids)
    : _orientable(orientable), _p(p), _q(q), _r(r),
      _gluingDataForSolid(getGluingDataForSolid(p,q))
{
    _numSimplicesPerSolid = 0;

    if (_gluingDataForSolid) {
	while (_gluingDataForSolid[_numSimplicesPerSolid].values[0] != -1) {
	    _numSimplicesPerSolid++;
	}
    }

    _numSimplices = _numSimplicesPerSolid * numSolids;
}

bool
PlatonicTessellationContext::isValid() const
{
    return _gluingDataForSolid;
}

const std::set<Triangulation> &
PlatonicTessellationContext::execute()
{
    {
	#ifdef ENABLE_MULTI_THREADED
	Threadpool::RunningContext runningContext(_threadpool);
	#endif

	Triangulation N;
	_addPlatonicSolid(&N);
	_recurse(N);
    }

    #ifdef ENABLE_MULTI_THREADED
    return _result.get_set_unsafe();
    #else
    return _result;
    #endif
}
int
PlatonicTessellationContext::_getOpenTetrahedron(const Triangulation &trig) const
{
    int result = -1;
    int num = 0;

    for (int simplex = 1; simplex < trig.simplices.size(); simplex+=2) {

	if (trig.simplices[simplex].neighbors[3] == -1) {

	    int number = 0;
	    int otherSimplex = simplex;
	    while (number == 0 or
	       trig.simplices[otherSimplex].neighbors[3] != -1) {
		otherSimplex = 
		    trig.simplices[otherSimplex].neighbors[2 + number % 2];
		number++;
	    }

	    if (number > num) {
		result = simplex;
		num = number;
	    }

	}

    }

    return result;
}

int
PlatonicTessellationContext::_addPlatonicSolid(Triangulation *trig) const
{
    const int originalSize = trig->simplices.size();

    trig->simplices.resize(originalSize + _numSimplicesPerSolid);

    for (int i = 0; i < _numSimplicesPerSolid; i++) {
	for (int j = 0; j < 3; j++) {
	    trig->simplices[originalSize + i].neighbors[j] =
		originalSize + _gluingDataForSolid[i].values[j];
	}
    }

    return originalSize;
}

bool
PlatonicTessellationContext::_glueFaces(
    Triangulation *trig, int simplex1, int simplex2) const
{
    int number = 0;

    while (trig->simplices[simplex1].neighbors[3] == -1 and
	   trig->simplices[simplex2].neighbors[3] == -1) {
	if (simplex1 == simplex2) {
	    return false;
	}

	trig->glue(3, simplex1, simplex2);

	simplex1 = trig->simplices[simplex1].neighbors[number % 2];
	simplex2 = trig->simplices[simplex2].neighbors[number % 2];

	number++;
    }

    return number == 2 * _p;
}

PlatonicTessellationContext::_FixEdgeResult
PlatonicTessellationContext::_fixOneSimplex(
    Triangulation *trig, int simplex) const
{
    int otherSimplex = simplex;

    const int avoidSimplex = trig->simplices[simplex].neighbors[0];

    if (trig->simplices[simplex].neighbors[3] == -1) {
	int number = 0;
	while (number == 0 or
	       trig->simplices[otherSimplex].neighbors[3] != -1) {
	    otherSimplex = 
		trig->simplices[otherSimplex].neighbors[2 + number % 2];

	    if ((not _orientable) and
		(otherSimplex == avoidSimplex)) {
		return _EdgeInvalid;
	    }

	    number++;
	}
	number++;

	if (number > 2 * _r) {
	    return _EdgeInvalid;
	}

	if (number == 2 * _r) {
	    if (not _glueFaces(trig, simplex, otherSimplex)) {
		return _EdgeInvalid;
	    }
	    return _EdgeFixed;
	}

    } else {
	for (int number = 0; number < 2 * _r; number++) {
	    
	    otherSimplex =
		trig->simplices[otherSimplex].neighbors[2 + number % 2];
	    
	    if (otherSimplex == -1) {  // Case treated eventually by the above code
		return _EdgeValid;
	    }

	    if ((not _orientable) and
		(otherSimplex == avoidSimplex)) {
		return _EdgeInvalid;
	    }
	    
	    if (simplex == otherSimplex xor number == 2 * _r - 1) { 
		return _EdgeInvalid;
	    }
	}
    }

    return _EdgeValid;
}

PlatonicTessellationContext::_FixEdgeResult
PlatonicTessellationContext::_fixSimplices(Triangulation *trig) const
{
    bool fixedEdge;

    do {
	fixedEdge = false;

	for (int i = 0; i < trig->simplices.size(); i++) {
	    const _FixEdgeResult result = _fixOneSimplex(trig, i);
	    if (result == _EdgeInvalid) {
		return result;
	    }
	    if (result == _EdgeFixed) {
		fixedEdge = true;
	    }
	}

    } while (fixedEdge);
    
    return _EdgeValid;
}

PlatonicTessellationContext::_MyIsomorphismSignature
PlatonicTessellationContext::_myIsomorphismSignature(
    const Triangulation &trig) const
{
    const int num = trig.simplices.size() / (2 * _p);

    _MyIsomorphismSignature result(num);

    for (int i = 0; i < num; i++) {
	result[i] = trig.simplices[2 * _p * i].neighbors[3];
    }

    return result;
}

// The main function: it recurses to build all the triangulations
// M: the partial triangulation build so far, will be modified by gluing up
// the edges.
// max_tets: the maximal number of tetrahedra considered
// orientable: whether to return orientable or nonorientable triangulations
// already_seen: keeps track of isomorphism signature already handled
// result: result will be written in here
void PlatonicTessellationContext::_recurse(Triangulation M, int depth)
{
    if (_fixSimplices(&M) == _EdgeInvalid) {
	return;
    }
  
    const Triangulation canonicalM = M.canonicallyRelabeled();
	
    {
	const _MyIsomorphismSignature isoSig =
	    _myIsomorphismSignature(canonicalM);
	
	{
	    // Bail if already handled earlier, insert otherwise.
	    if (not _already_seen.insert(isoSig).second) {
		return;
	    }
	}
    }
    
    const int openTetrahedron1 = _getOpenTetrahedron(M);

    if (openTetrahedron1 == -1) {
	_result.insert(canonicalM);
	return;
    }
    

    // If maximal number of tetrahedra has not be reached yet, glue
    // a new tetrahedron
    if (M.simplices.size() < _numSimplices) {
	// Make a copy of triangulation
	Triangulation N(M);
	
	const int newSolid = _addPlatonicSolid(&N);
	_glueFaces(&N, openTetrahedron1, newSolid);
	#ifdef ENABLE_MULTI_THREADED
	_threadpool.scheduleOrExecute(
	    boost::bind(
		&PlatonicTessellationContext::_recurse,
		this, N, depth + 1));
	#else
	_recurse(N, depth+1);
	#endif
    }

    for (int tetIndex2 = 0;
	 tetIndex2 < M.simplices.size();
	 tetIndex2++) {
	
	if (tetIndex2 % 2 == 0 or not _orientable) {

	    if (M.simplices[tetIndex2].neighbors[3] == -1) {
		    
		Triangulation N(M);

		if (_glueFaces(&N,
			       openTetrahedron1,
			       tetIndex2)) {
		    #ifdef ENABLE_MULTI_THREADED
		    _threadpool.scheduleOrExecute(
			boost::bind(
			    &PlatonicTessellationContext::_recurse,
			    this, N, depth + 1));
		    #else
		    _recurse(N, depth+1);
		    #endif
		}
	    }
	}
    }
}

