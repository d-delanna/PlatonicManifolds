#ifndef __TRIANGULATION_H__
#define __TRIANGULATION_H__

#include <vector>
#include <string>

class Simplex
{
public:
    // All the data: indices of the four neighbors, -1 if unglued face
    short neighbors[4];

    // Constructor
    Simplex();
};

bool operator<(const Simplex &self, const Simplex &other);

bool operator==(const Simplex &self, const Simplex &other);

class Triangulation
{
public:
    // All the data
    std::vector<Simplex> simplices;

    // Constructor
    Triangulation(int size = 0);

    // Gluing
    void glue(int f, int s1, int s2);

    // Bring into canonical form. Two triangulaions are canonically isomorphic
    // if and only if their canonical form is the same.
    Triangulation canonicallyRelabeled() const;

    // Testing
    void testing() const;
    bool isConsistent() const;
private:
    void _canonicalRelabeling1();
    void _swapLabels(int s1, int s2);
};

bool
operator<(const Triangulation &a, const Triangulation &b);

bool
operator==(const Triangulation &a, const Triangulation &b);

#endif
