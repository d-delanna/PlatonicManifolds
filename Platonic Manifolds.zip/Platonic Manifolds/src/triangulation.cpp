#include "triangulation.h"

// Included for testing
#include "triangulationToRegina.h"
#include <cstdlib>

#include <iostream>  // for std::cout and std::endl

bool operator<(const Simplex &self, const Simplex &other)
{
    for (int k = 0; k < 4; k++) {
	if (self.neighbors[k] < other.neighbors[k]) {
	    return true;
	}
	if (self.neighbors[k] > other.neighbors[k]) {
	    return false;
	}
    }
    return false;
}

bool operator==(const Simplex &self, const Simplex &other)
{
    for (int k = 0; k < 4; k++) {
	if (self.neighbors[k] != other.neighbors[k]) {
	    return false;
	}
    }
    return true;
}

bool
operator<(const Triangulation &a, const Triangulation &b)
{
    return a.simplices < b.simplices;
}

bool
operator==(const Triangulation &a, const Triangulation &b)
{
    return a.simplices == b.simplices;
}

Simplex::Simplex()
{
    for (int k = 0; k < 4; k++) {
	neighbors[k] = -1;
    }
}

Triangulation::Triangulation(int size)
    : simplices(size)
{
}

void
Triangulation::_swapLabels(int s1, int s2)
{
    std::swap(simplices[s1],simplices[s2]);

    for (int k = 0; k < 4; k++) {
	const int n1 = simplices[s1].neighbors[k];
	if (n1 != -1) {
	    simplices[n1].neighbors[k] = (n1 != s1) ? s1 : s2;
	}
	const int n2 = simplices[s2].neighbors[k];
	if (n2 != -1) {
	    simplices[n2].neighbors[k] = (n2 != s2) ? s2 : s1;
	}
    }
}

void
Triangulation::_canonicalRelabeling1()
{
    int determiningSimplex[4] = {0, 0, 0, 0};

    int nextSimplexToDetermine = 1;

    while (true) {
	for (int k = 0; k < 4; k++) {
	    if (determiningSimplex[k] < nextSimplexToDetermine) {
		const int n = simplices[determiningSimplex[k]].neighbors[k];
		if (n >= nextSimplexToDetermine) {
		    if (n > nextSimplexToDetermine) {
			_swapLabels(n, nextSimplexToDetermine);
		    }
		    nextSimplexToDetermine++;
		    if (nextSimplexToDetermine == simplices.size()) {
			return;
		    }
		}
		determiningSimplex[k]++;
		break;
	    }
	}
    }
}

Triangulation
Triangulation::canonicallyRelabeled() const
{
    Triangulation best(*this);
    for (int i = 1; i < simplices.size(); i++) {
	Triangulation candidate(*this);
	candidate._swapLabels(0, i);
	candidate._canonicalRelabeling1();
	if (candidate < best) {
	    best = candidate;
	}
    }
    return best;
}

void
Triangulation::glue(int f, int s1, int s2)
{
    simplices[s1].neighbors[f] = s2;
    simplices[s2].neighbors[f] = s1;
}
    
bool
Triangulation::isConsistent() const
{
    for (int i = 0; i < simplices.size(); i++) {
	for (int k = 0; k < 4; k++) {
	    const int n = simplices[i].neighbors[k];
	    if (n != -1 and simplices[n].neighbors[k] !=  i) {
		return false;
	    }
	    if (n != -1 and i == n) {
		return false;
	    }
	}
    }
    return true;
}

// Testing

void
Triangulation::testing() const
{
    Triangulation canon1 = canonicallyRelabeled();

    for (int i = 0; i < 100; i++) {

	Triangulation shuffled(*this);

	for (int j = 0; j < i; j++) {
	    const int a = rand() % simplices.size();
	    const int b = rand() % simplices.size();
	    if (a != b) {
		shuffled._swapLabels(a, b);
	    }
	}

	const regina::Triangulation t1 = triangulationToRegina(*this);  // "regina::NTriangulation" deprecated
	const regina::Triangulation t2 = triangulationToRegina(shuffled); // "regina::NTriangulation" deprecated

	if (t1.isoSig() != t2.isoSig()) {
	    std::cout << "isomorphism signature changed" << std::endl;
	}

	if (not (canon1 == shuffled.canonicallyRelabeled())) {
	    std::cout << "canonical relabeling changed" << std::endl;
	}

    }

}
