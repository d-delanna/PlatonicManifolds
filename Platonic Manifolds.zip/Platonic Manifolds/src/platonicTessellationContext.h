#ifndef __PLATONIC_TESSELLATION_CONTEXT_H__
#define __PLATONIC_TESSELLATION_CONTEXT_H__

#include "triangulation.h"

#ifdef ENABLE_MULTI_THREADED
#include "threadSafeSet.h"
#include "threadpool.h"
#endif

#include <vector>
#include <set>

struct GluingTriple;

class PlatonicTessellationContext
{
public:

    PlatonicTessellationContext(
	bool orientable, int p, int q, int r, int numSolids);

    bool isValid() const;

    const std::set<Triangulation> &execute();

private:

    // The result of checking the number of tetrahedra adjacent to an edge
    typedef enum {
	_EdgeValid,    // The number is less than 6 for an open edge or exactly 6
	_EdgeFixed,    // The number is 6 for an open edge that was closed up
	_EdgeInvalid   // The number is less than 6 for a closed edge or greater 6
    } _FixEdgeResult;
  
    typedef std::vector<short> _MyIsomorphismSignature;

    _MyIsomorphismSignature
    _myIsomorphismSignature(const Triangulation &trig) const;

    int _addPlatonicSolid(Triangulation *trig) const;

    bool _glueFaces(
	Triangulation *trig, int simplex1, int simplex2) const;

    _FixEdgeResult _fixOneSimplex(Triangulation *trig, int simplex) const;

    _FixEdgeResult _fixSimplices(Triangulation *trig) const;

    int _getOpenTetrahedron(const Triangulation &trig) const;

    void _recurse(Triangulation trig, int depth = 0);
private:
    const bool _orientable;
    const int _p, _q, _r;
    const GluingTriple* _gluingDataForSolid;

    int _numSimplicesPerSolid;
    int _numSimplices;

    #ifdef ENABLE_MULTI_THREADED
    ThreadSafeSet<Triangulation> _result;
    ThreadSafeSet<_MyIsomorphismSignature> _already_seen;

    Threadpool _threadpool;
    #else
    std::set<Triangulation> _result;
    std::set<_MyIsomorphismSignature> _already_seen;
    #endif
};

#endif
