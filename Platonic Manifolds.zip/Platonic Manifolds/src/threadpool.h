#ifndef __THREADPOOL_H__
#define __THREADPOOL_H__

#include <boost/function.hpp>
#include <boost/thread/thread.hpp>
#include <boost/thread/mutex.hpp>

#include <vector>

class Threadpool
{
public:
    Threadpool();

    typedef boost::function<void ()> Task;
    void scheduleOrExecute(const Task &task);

    class RunningContext {
    public:
	RunningContext(Threadpool &threadpool);
	~RunningContext();

    private:
	Threadpool &_threadpool;
    };

private:
    void _worker();
    void _waitToFinish();

    std::vector<boost::thread*> _threads;
    const int _max_num_threads;
    int _num_running_threads_and_pending_tasks;
    std::vector<Task> _pending_tasks;
    bool _running;
    
    boost::mutex _mutex;
};

#endif
