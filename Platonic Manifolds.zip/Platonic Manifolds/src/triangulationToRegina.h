#ifndef __TRIANGULATION_TO_REGINA_H__
#define __TRIANGULATION_TO_REGINA_H__

#include "triangulation.h" // "triangulation/ntriangulation.h" deprecated
#include <triangulation/dim3.h>

class Triangulation;

regina::Triangulation triangulationToRegina(const class Triangulation &trig); // regina::NTriangulation deprecated

#endif
