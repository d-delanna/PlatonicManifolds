#include "triangulationToRegina.h"

#include "triangulation.h"

regina::Triangulation triangulationToRegina(const class Triangulation &trig) // "regina::NTriangulation" deprecated
{
    regina::Triangulation reginaTrig; // "regina::NTriangulation" deprecated
    for (int i = 0; i < trig.simplices.size(); i++) {
	regina::Tetrahedron *tet = reginaTrig.newTetrahedron(); // "regina::NTetrahedron" deprecated
	for (int k = 0; k < 4; k++) {
	    const int n = trig.simplices[i].neighbors[k];
	    if (n != -1 and n < i) {
		tet->joinTo(k, reginaTrig.getTetrahedron(n), regina::Perm4()); // "regina::NPerm4" deprecated
	    }	
	}
    }

    return reginaTrig;
}
