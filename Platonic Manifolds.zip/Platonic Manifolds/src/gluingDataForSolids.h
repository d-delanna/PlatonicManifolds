#ifndef __GLUING_DATA_FOR_SOLIDS_H__
#define __GLUING_DATA_FOR_SOLIDS_H__

struct GluingTriple {
    int values[3];
};

const GluingTriple* getGluingDataForSolid(int p, int q);

#endif

