#include "platonicTessellationContext.h"
#include "triangulationToRegina.h"

#include <cstring>
#include <cstdlib>

#include <iostream>  // for std::cerr and std::endl

typedef std::pair<int, std::string> NumIsoSig;
typedef std::set<NumIsoSig> NumIsoSigContainer;

// Print usage
void printUsage()
{
    std::cerr << "Usage: genIsomoSigsOfPlatonicTessellations "
              << "p q r NUM_SOLIDS [n|o]\n\n"
              << "    {p,q,r} is the type of tessellation\n"
              << "    NUM_SOLIDS the maximum number of solids\n"
              << "    n is for non-orientable, o for orientable (default)"
	      << std::endl;
    exit(1);
}


int main(int argc, char** argv)
{
    if (argc < 5 or argc > 6) {
	printUsage();
    }

    // Get number of tets
    const int p = std::atoi(argv[1]);
    const int q = std::atoi(argv[2]);
    const int r = std::atoi(argv[3]);
    const int number_solids = std::atoi(argv[4]);

    // Fallback to orientable
    bool orientable = true;

    // Parse orientability
    if (argc == 6) {
	if (std::strcmp(argv[5], "n") == 0) {
	    orientable = false;
	} else if (std::strcmp(argv[5], "o") != 0) {
	    printUsage();
	}
    }

    PlatonicTessellationContext context(orientable, p, q, r, number_solids);

    if (not context.isValid()) {
	std::cerr << "Tessellation {"
		  << p << ", " << q << ", " << r
		  << "} not supported." << std::endl;
	exit(1);
    }

    const std::set<Triangulation> &raw_result = context.execute();

    NumIsoSigContainer result;
    for (std::set<Triangulation>::const_iterator it = raw_result.begin();
	 it != raw_result.end(); ++it) {

	const regina::Triangulation N = triangulationToRegina(*it); // "regina::NTriangulation" deprecated

	if (orientable or not N.isOrientable()) {
	    if (not result.insert(
		    NumIsoSig(N.getNumberOfTetrahedra(), N.isoSig())).second) {
		#ifdef REPORT_DUPLICATE_ISOSIGS
		std::cout << "Duplicate isomorphism signature: "
			  <<  N.isoSig()<< std::endl;
		#endif
	    }
	}
    }

    // And output the result, std::set's iterator will go
    // through this in lexicographic order.
    for(NumIsoSigContainer::const_iterator it = result.begin();
	it != result.end(); ++it) {
	std::cout << it->second << std::endl;
    }
}
