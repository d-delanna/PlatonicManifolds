#!/usr/bin/python

from snappy import Link
from spherogram import DTcodec

import sys

sys.path.append('.')

from platonicCensus import OctahedralOrientableCuspedCensus

def identify_octahedral_manifold(link):
    for i in range(100):
        mfd = link.exterior()
        oct_mfd = OctahedralOrientableCuspedCensus.identify(mfd)
        if oct_mfd:
            return oct_mfd.name()

    raise Exception("Failed to identify %s" % link.PD_code())

def get_isomorphism_signature(link):
    for i in range(100):
        mfd = link.exterior()
        isomo = mfd.isometry_signature()
        if isomo:
            return isomo
    raise Exception("Failed to get isometry signature %s" % link.PD_code())

def get_geometric(name, M):

    for i in range(100):
        if 'positive' in M.solution_type():
            return M
        M.randomize()

    if 'positive' in M.solution_type():
        return M

    print >> sys.stderr, ("WARNING not geometric %s" % name)

    return M

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print >>sys.stderr, (
            "Usage: PDcodesToOctahedralMfd.py FILE_OF_PD_CODES")
        sys.exit(1)

    already_seen = set()
    already_seen_isomosig = set()

    for pd_code in open(sys.argv[1]).read().split('\n'):
        if pd_code:
            print >>sys.stderr, ".",

            link = Link(eval(pd_code))

            isomosig = get_isomorphism_signature(link)

            if not isomosig in already_seen_isomosig:
                already_seen_isomosig.add(isomosig)

                oct_mfd_name = identify_octahedral_manifold(link)

                if not oct_mfd_name in already_seen:
                    already_seen.add(oct_mfd_name)

                    geom_mfd = get_geometric(oct_mfd_name, link.exterior())
                    
                    decorated_isosig = geom_mfd.triangulation_isosig(
                        decorated=True)
                
                    dt_code = DTcodec(link.DT_code()).encode(
                        header = False, alphabetical=True, flips='auto')

                    print oct_mfd_name, decorated_isosig, dt_code
                    sys.stdout.flush()


