#!/usr/bin/python

import spherogram

import sqlite3

import sys
import shutil
import binascii

alter_querries = [
    "ALTER TABLE %s ADD COLUMN DT text",
    "ALTER TABLE %s ADD COLUMN isAugKTG int"
]

update_query = """
UPDATE %s SET isAugKTG = 1, DT = '%s', triangulation = '%s'  WHERE name = '%s'
"""

if __name__ == '__main__':
    if not len(sys.argv) == 5:
        print >> sys.stderr, ("Usage: addDTcodesToDB.py INPUT_FILE TABLE_NAME "
                              "IN.SQLITE OUT.SQLITE")
        sys.exit(1)

    manifold_to_DT_codes_file, table_name, in_sql_file, out_sql_file = (
        sys.argv[1:5])
    
    print "Copying..."
    shutil.copyfile(in_sql_file, out_sql_file)

    connection = sqlite3.connect(out_sql_file)
    for i, alter_query in enumerate(alter_querries):
        print "Altering table (%d/%d)..." % (i+1, len(alter_querries))
        connection.execute(alter_query % table_name)

    print "Adding DT codes",
    for l in open(manifold_to_DT_codes_file).read().split('\n'):
        if l:
            name, decorated_isosig, DT_code = l.split()
            print update_query % (table_name, DT_code, decorated_isosig, name)
            connection.execute(
                update_query % (table_name, DT_code, decorated_isosig, name))

            print ".",
            sys.stdout.flush()

    print
    print "Committing..."
    connection.commit()
    connection.close()

    print "Done"


    
