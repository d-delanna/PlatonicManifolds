#ifndef __SPINNETWORK_HALFEDGE__
#define __SPINNETWORK_HALFEDGE__

#include <boost/shared_ptr.hpp>
#include <boost/weak_ptr.hpp>

#include <vector>

namespace SpinNetwork {
    class HalfEdge;

    typedef boost::shared_ptr<HalfEdge> HalfEdgeSharedPtr;
    typedef boost::weak_ptr<HalfEdge> HalfEdgePtr;
    typedef std::vector<HalfEdgeSharedPtr> HalfEdgeSharedPtrVector;
    typedef std::vector<HalfEdgePtr> HalfEdgePtrVector;

    class HalfEdge {
        //
        // Represents a half of an edge of a graph embedded in the plane or
        // a spin network.
        //
        // To explain the encoding, consider the following section of an
        // embedded graph with two four valent and one trivalent vertex.
        //
        //         |             |         /
        //         |             |        /
        //         |             |       /
        //         |             |      /
        // --------+-------------+-----
        //         |             |      \
        //         |             |       \
        //         |             |        \
        //         |             |         \
        //
        // We split every edge in two halves (at the *'s) and label the
        // HalfEdge's.
        //
        //         |             |         /
        //         *             *        *
        //       h2|           h8|       /h10
        //         |   h1        |  h7  /
        // --*-----+------*------+----- 
        //    h3   |        h5   |      \
        //         |h4           |h6     \h9
        //         *             *        *
        //         |             |         \
        //
        // We indicate that h1 and h5 are glued (at *) to form one edge of
        // the graph by setting h1->otherHalf = h5 and h5->otherHalf = h1
        // (perferably, use Join(h1, h5) instead).
        //
        // We also need to indicate which half edges meet at a vertex and
        // in which order (counter-clockwise). For example, we have
        // h1->next = h2; h2->next = h3; h3->next = h4; h4->next = h1; and
        // h7->next = h9; h9->next = h10; h10->next = h7
        // (perferably, use FormVertex(h1, h2, h3, h4) and
        // FormVertex(h7, h9, h10) instead).
        //
        // We can use a HalfEdge's isUnder to indicate crossings. For example,
        // set h2->isUnder, h4->isUnder, h5->isUnder, h7->isUnder to achieve:
        //
        //         |             |         /
        //         *             *        *
        //       h2|           h8|       /h10
        //         |   h1        |  h7  /
        // --*------------*----- | ---- 
        //    h3   |        h5   |      \
        //         |h4           |h6     \h9
        //         *             *        *
        //         |             |         \
        //
 
    public:
        // Create a new half edge
	static HalfEdgeSharedPtr New(int index_);

        // Data as indicated above
	HalfEdgePtr otherHalf;
	HalfEdgePtr next;
        bool isUnder;
    
        // Index of an half edge in a Network class that owns and indexes
        // the half edges. This is managed by NetworkBase and should not
        // be touched by other clients.
	int index;

        // Number of half edges that meet at the vertex this half edge
        // connects to (e.g., h1->Valency() is 4, h7->Valency() is 3).
	int Valency() const;
    private:
        HalfEdge(int index_)
	    : isUnder(false), index(index_) {}
    };

    // Returns true if two half edges meet at the same vertex, e.g., h1 and h2
    // do, but h7 and h2 do not.
    bool BelongToSameVertex(const HalfEdgePtr &, const HalfEdgePtr &);
	
    void Join(const HalfEdgePtr &, const HalfEdgePtr &);

    void FormVertex(const HalfEdgePtr &,
		    const HalfEdgePtr &,
		    const HalfEdgePtr &);
    void FormVertex(const HalfEdgePtr &,
		    const HalfEdgePtr &,
		    const HalfEdgePtr &,
		    const HalfEdgePtr &);
    
    // Returns true if all half edges in the given array are distinct.
    template<size_t n>
    bool AreHalfEdgesDistinct(const HalfEdgeSharedPtr e[n]);

    // Returns true if all half edges in the list obtained by concatening
    // the two given arrays are distinct.
    template<size_t n, size_t m>
    bool AreHalfEdgesDistinct
	(const HalfEdgeSharedPtr e[n], const HalfEdgeSharedPtr f[m]);


    template<size_t n>
    bool AreHalfEdgesDistinct(const HalfEdgeSharedPtr e[n]) {
	for (int i = 0; i < n; i++) {
	    for (int j = 0; j < i; j++) {
		if (e[i] == e[j]) {
		    return false;
		}
	    }
	}
	return true;
    }

    template<size_t n, size_t m>
    bool AreHalfEdgesDistinct
	(const HalfEdgeSharedPtr e[n], const HalfEdgeSharedPtr f[m]) {
	
	for (int i = 0; i < n; i++) {
	    for (int j = 0; j < m; j++) {
		if (e[i] == f[j]) {
		    return false;
		}
	    }
	}

	return AreHalfEdgesDistinct<n>(e) and AreHalfEdgesDistinct<m>(f);
    }

}

#endif
