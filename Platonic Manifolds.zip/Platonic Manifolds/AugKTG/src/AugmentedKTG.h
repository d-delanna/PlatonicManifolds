#ifndef __SPINNETWORK_AUGMENTEDKTG_H__
#define __SPINNETWORK_AUGMENTEDKTG_H__

#include "NetworkBase.h"

#include <boost/operators.hpp>

#include <string>

namespace SpinNetwork {

    class AugmentedKTG :
        public NetworkBase,
	public boost::less_than_comparable<AugmentedKTG> {
    public:
         // Represents a Augmented Knotted Trivalent Graph.

	typedef std::vector<unsigned short> IsomorphismSignature;

        // Constructs embedded complete graph of 4 vertices.
	AugmentedKTG();
	AugmentedKTG(const IsomorphismSignature &);

	bool HasTrivalentVertex() const; 

	bool CanPerformAMove(const HalfEdgePtr &) const;
	void PerformAMove(const HalfEdgePtr &);

	HalfEdgePtr CanPerformUOrXMove(const HalfEdgePtr &) const;
	void PerformUOrXMove(const HalfEdgePtr &, bool withCrossing);

	void PerformAllPossibleReidemeisterTypeOneMoves();
	void PerformReidemeisterMovesGreedily();

	// Helpers to remove Reidemeister 1 Moves
	bool CanPerformReidemeisterTypeOneMove(const HalfEdgePtr &) const;
	void PerformReidemeisterTypeOneMove(const HalfEdgePtr &);

	bool CanPerformReidemeisterTypeTwoMove(const HalfEdgePtr &) const;
	void PerformReidemeisterTypeTwoMove(const HalfEdgePtr &);

	bool CanPerformReidemeisterLikeMove(const HalfEdgePtr &) const;
	void PerformReidemeisterLikeMove(const HalfEdgePtr &);

	bool CanPerformUntwistTrivalentVertex(const HalfEdgePtr &) const;
	void PerformUntwistTrivalentVertex(const HalfEdgePtr &);

	// Helpers to do a U/X-move
	HalfEdgePtr PerformReverseReidemeisterLikeMove(const HalfEdgePtr &);
	void AddBelt(const HalfEdgePtr &);
	void JoinTwoTrivalentVertices(const HalfEdgePtr &, bool withCrossing);

	std::string GetPDCode() const;

	virtual bool IsConsistent(std::string *reason = NULL) const;

	bool operator<(const AugmentedKTG &) const;

	IsomorphismSignature ComputeIsomorphismSignature() const;

	AugmentedKTG Canonical() const;

	// Helpers for canonical
	std::pair<int, std::vector<int> >
	    GetHalfEdgeToFlippableLoopIndex() const;
	void GloballyFlipCrossings();
	void CanonicallyFlipLoops();

    private:
	void _SwapHalfEdges(int, int);
	void _SwapHalfEdges(int, const HalfEdgePtr &);
	void _Canonize(int);
    };
}

#endif
