#include "RecurseAugmentedKTG.h"

#include "HalfEdge.h"

namespace SpinNetwork {
    
    static
    void
    _RecurseAugmentedKTG(
	const AugmentedKTG &t, int depth, AugKTGIsoSigSet *result) {

	if (not result->insert(t.ComputeIsomorphismSignature()).second) {
	    return;
	}

	if (depth > 0) {
	    for (int i = 0; i < t.GetNumHalfEdges(); i++) {
		AugmentedKTG n(t);
		n.PerformAMove(n.GetHalfEdge(i));
		_RecurseAugmentedKTG(n, depth - 1, result);
	    }
	} else {
	    if (t.HasTrivalentVertex()) {
		for (int i = 0; i < t.GetNumHalfEdges(); i++) {
		    if (const HalfEdgeSharedPtr e =
  	  	  	  t.CanPerformUOrXMove(t.GetHalfEdge(i)).lock()) {
			if (i < e->index) {
			    for (int j = 0; j < 2; j++) {
				AugmentedKTG n(t);
				n.PerformUOrXMove(n.GetHalfEdge(i), bool(j));
//				n.PerformAllPossibleReidemeisterTypeOneMoves();
				n.PerformReidemeisterMovesGreedily();
				_RecurseAugmentedKTG(n, 0, result);
			    }
			}
		    }
		}
	    }
	}
    }

    AugKTGIsoSigSet
    RecurseAugmentedKTG(int numAMoves)
    {
	AugKTGIsoSigSet result;
	_RecurseAugmentedKTG(AugmentedKTG(), numAMoves, &result);
	return result;
    }
}
