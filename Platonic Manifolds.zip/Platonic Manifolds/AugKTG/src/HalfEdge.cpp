#include "HalfEdge.h"

#include <iostream>

#include <set>

namespace SpinNetwork {
    
    /* static */
    HalfEdgeSharedPtr
    HalfEdge::New(int index_) {
	return HalfEdgeSharedPtr(new HalfEdge(index_));
    }

    int
    HalfEdge::Valency() const {
	int result = 1;

	HalfEdgeSharedPtr current = next.lock();
	while (current) {
	    if (current.get() == this) {
		return result;
	    }

	    current = current->next.lock();
	    result++;
	}

	return 0;
    }

    bool BelongToSameVertex(const HalfEdgePtr &a, const HalfEdgePtr &b) {
	
	const HalfEdgeSharedPtr ha = a.lock();
	const HalfEdgeSharedPtr hb = b.lock();
	
	if (not (ha and hb)) {
	    return false;
	}

	HalfEdgeSharedPtr current = ha->next.lock();
	
	while(current) {
	    if (current == hb) {
		return true;
	    }
	    if (current == ha) {
		return false;
	    }
	    current = current->next.lock();
	}

	return false;
    }

    void Join(const HalfEdgePtr &h0, const HalfEdgePtr &h1) {
	h0.lock()->otherHalf = h1;
	h1.lock()->otherHalf = h0;
    }

    void FormVertex(const HalfEdgePtr &h0,
		    const HalfEdgePtr &h1,
		    const HalfEdgePtr &h2) {
	h0.lock()->next = h1;
	h1.lock()->next = h2;
	h2.lock()->next = h0;
    }

    void FormVertex(const HalfEdgePtr &h0,
		    const HalfEdgePtr &h1,
		    const HalfEdgePtr &h2,
		    const HalfEdgePtr &h3) {
	h0.lock()->next = h1;
	h1.lock()->next = h2;
	h2.lock()->next = h3;
	h3.lock()->next = h0;
    }
}
