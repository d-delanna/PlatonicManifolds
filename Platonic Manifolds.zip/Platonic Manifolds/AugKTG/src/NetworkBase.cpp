#include "NetworkBase.h"

#include "HalfEdge.h"

#include <boost/lexical_cast.hpp>

#include <boost/version.hpp>

#if BOOST_VERSION >= 105600
#include <boost/core/demangle.hpp>
#endif

#include <algorithm>
#include <iostream>
#include <cstdlib>

namespace SpinNetwork {

    NetworkBase::NetworkBase(const NetworkBase &other)
    {
	*this = other;
    }

    NetworkBase &
    NetworkBase::operator=(const NetworkBase &other) {
	_halfEdges.clear();

	const int num = other._halfEdges.size();

	_halfEdges.reserve(num);
	for (int i = 0; i < num; i++) {
	    CreateHalfEdge();
	}

	for (int i = 0; i < num; i++) {
	    if (const HalfEdgeSharedPtr otherHalf =
  		    other._halfEdges[i]->otherHalf.lock()) {
		_halfEdges[i]->otherHalf = _halfEdges[otherHalf->index];
	    }
	    if (const HalfEdgeSharedPtr next =
        	    other._halfEdges[i]->next.lock()) {
		_halfEdges[i]->next = _halfEdges[next->index];
	    }
	    
	    _halfEdges[i]->isUnder = other._halfEdges[i]->isUnder;
	}
	return *this;
    }

    HalfEdgePtr
    NetworkBase::CreateHalfEdge() {
	const HalfEdgeSharedPtr e = HalfEdge::New(_halfEdges.size());
	_halfEdges.push_back(e);
	return e;
    }

    void
    NetworkBase::DeleteHalfEdge(const HalfEdgePtr &halfEdge) {
	const int index = halfEdge.lock()->index;
	_halfEdges[index] = _halfEdges[_halfEdges.size()-1];
	_halfEdges[index]->index = index;
	_halfEdges.resize(_halfEdges.size()-1);
    }

    std::string
    NetworkBase::Dump() const {
	std::string result;
	result += "---------------------------------------------------------\n";
	result += "Dump of ";
        #if BOOST_VERSION >= 105600
	result += boost::core::demangle(typeid(*this).name());
	result += " (derived from NetworkBase)\n";
	#else
	result += "NetworkBase\n";
        #endif
	

	for (int i = 0; i < _halfEdges.size(); i++) {
	    result += "        " + boost::lexical_cast<std::string>(i);
	    if (const HalfEdgeSharedPtr e = _halfEdges[i]->otherHalf.lock()) {
		result += "   otherHalf= ";
		result += boost::lexical_cast<std::string>(e->index);
	    } else {
		result += "                ";
	    }
	    if (const HalfEdgeSharedPtr e = _halfEdges[i]->next.lock()) {
		result += "   next= ";
		result += boost::lexical_cast<std::string>(e->index);
	    }
	    if (_halfEdges[i]->isUnder) {
		result += "   isUnder";
	    }
	    result += "\n";
	}
	result += "---------------------------------------------------------\n";
	return result;
    }
    
    /* virtual */
    bool
    NetworkBase::IsConsistent(std::string *reason) const {
	for (int i = 0; i < _halfEdges.size(); i++) {
	    if (_halfEdges[i]->index != i) {
		if (reason) {
		    *reason =
			"Index of half edge " +
			boost::lexical_cast<std::string>(i) +
			" is " +
			boost::lexical_cast<std::string>(_halfEdges[i]->index) +
			".";
		}
		return false;
	    }
	}
	    
	std::vector<int> isNext(_halfEdges.size(), -1);

	for (int i = 0; i < _halfEdges.size(); i++) {
	    if (const HalfEdgeSharedPtr next = _halfEdges[i]->next.lock()) {
		if (isNext[next->index] != -1) {
		    if (reason) {
			*reason =
			    "The next pointers of the half edge " +
			    boost::lexical_cast<std::string>(
				isNext[next->index]) +
			    " and half edge " +
			    boost::lexical_cast<std::string>(i) +
			    " are pointing to the same half edge " +
			    boost::lexical_cast<std::string>(next->index) +
			    ".";
		    }
		    return false;
		}
		isNext[next->index] = i;
	    }

	    const HalfEdgeSharedPtr other = _halfEdges[i]->otherHalf.lock();
	    if (other) {
		if (other == _halfEdges[i]) {
		    if (reason) {
			*reason =
			    "The otherHalf pointer of half edge " +
			    boost::lexical_cast<std::string>(i) +
			    "is pointing to itself.";
		    }
		    return false;
		}
		const HalfEdgeSharedPtr otherOther = other->otherHalf.lock();
		if (not otherOther) {
		    if (reason) {
			*reason =
			    "The otherHalf of the otherHalf pointer of half "
			    "edge " +
			    boost::lexical_cast<std::string>(i) +
			    "is NULL.";
		    }
		    return false;
		}
		if (otherOther != _halfEdges[i]) {
		    if (reason) {
			*reason =
			    "The otherHalf of the otherHalf pointer of half "
			    "edge " +
			    boost::lexical_cast<std::string>(i) +
			    " is not pointing to the half edge itself.";
		    }
		    return false;
		}
	    }
	}
	return true;
    }

    NetworkBase::ConsistencyCheckContext::ConsistencyCheckContext(
	NetworkBase *net, const std::string &msg) :
	_net(net), _start(*net), _msg(msg) {
	
	std::string reason;

	if (not _net->IsConsistent(&reason)) {
	    std::cerr << _net->Dump();
	    std::cerr << "Exiting because Network is not consistent : ";
	    std::cerr << reason << std::endl;
	    std::cerr << "This happened on entering a consistency check block "
		      << "for: " << msg << std::endl;
	    std::exit(1);
	}
    }

    NetworkBase::ConsistencyCheckContext::~ConsistencyCheckContext() {
	std::string reason;

	if (not _net->IsConsistent(&reason)) {
	    std::cerr << "Network upon entering consistency check block:\n";
	    std::cerr << _start.Dump();
	    std::cerr << "--------------------------------------------------\n";
	    std::cerr << "--------------------------------------------------\n";
	    std::cerr << "--------------------------------------------------\n";
	    std::cerr << "Network upon exiting consistency check block:\n";
	    std::cerr << _net->Dump();
	    std::cerr << "Exiting because network is not consistent :";
	    std::cerr << reason << std::endl;
	    std::cerr << "Network got corrupted in consistency check block "
		      << "for: " << _msg << std::endl;
	    std::exit(1);
	}
    }
}
