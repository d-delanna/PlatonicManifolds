#ifndef __SPINNETWORK_NETWORKBASE__
#define __SPINNETWORK_NETWORKBASE__

#include <boost/shared_ptr.hpp>
#include <boost/weak_ptr.hpp>

#include <vector>
#include <string>

namespace SpinNetwork {
    class HalfEdge;

    typedef boost::shared_ptr<HalfEdge> HalfEdgeSharedPtr;
    typedef boost::weak_ptr<HalfEdge> HalfEdgePtr;
    typedef std::vector<HalfEdgeSharedPtr> HalfEdgeSharedPtrVector;
    typedef std::vector<HalfEdgePtr> HalfEdgePtrVector;

    class NetworkBase {
        // A base class for networks of HalfEdge's.
    public:
        // Create a network
	NetworkBase() {}
        // Copy a network (this is a deep copy that creates an identical
        // network from new HalfEdge's).
	NetworkBase(const NetworkBase &);
	NetworkBase& operator=(const NetworkBase &);
	
        // Number of HalfEdges in the Network.
	int GetNumHalfEdges() const { return _halfEdges.size(); }
        // Access a particular HalfEdge
	HalfEdgePtr GetHalfEdge(int i) const { return _halfEdges[i]; }

        // Create and delete a HalfEdge
	HalfEdgePtr CreateHalfEdge();
	void DeleteHalfEdge(const HalfEdgePtr &);

        // Dump network
	std::string Dump() const;
        // Basic consistency check
	virtual bool IsConsistent(std::string *reason = NULL) const;

	class ConsistencyCheckContext;

    protected:
        // The network owns the half edges and manages them.
        // For any halfEdge h in this network, we have
        // _halfEdges[h->index] is h itself.
	HalfEdgeSharedPtrVector _halfEdges;
    };

    class NetworkBase::ConsistencyCheckContext {
    public:
        // An RAII class for debugging actions on a Network.
        // The class gets a pointer to a network and a debugging message.
        // The destructor checks whether the network is consistent (calling
        // the virtual method IsConsistent). If it is not, it gives debugging
        // output.
        // The debugging output includes a snapshot of the network of the time
        // when the ConsistencyCheckContext was instantiated, the current
        // network's state and the debugging message.
	ConsistencyCheckContext(NetworkBase *net, const std::string &msg);
	~ConsistencyCheckContext();
    private:
	const NetworkBase *_net;
	const NetworkBase _start;
	const std::string _msg;
    };
}

#endif
