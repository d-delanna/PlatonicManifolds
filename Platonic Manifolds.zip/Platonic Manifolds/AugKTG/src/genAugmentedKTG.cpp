#include "RecurseAugmentedKTG.h"

#include <iostream>

using namespace SpinNetwork;

void printUsage()
{
    std::cerr << "Usage: genAugmentedKTG NUM_A_MOVES"
	      << std::endl;
    exit(1);
}

int main(int argc, char** argv) {

    if (argc < 2) {
	printUsage();
    }

    const int n = std::atoi(argv[1]);

    const AugKTGIsoSigSet isoSigs = RecurseAugmentedKTG(n);

    for (AugKTGIsoSigSet::const_iterator it = isoSigs.begin();
	 it != isoSigs.end(); it++) {
	const AugmentedKTG network(*it);
	if (not network.HasTrivalentVertex()) {
	    std::cout << network.GetPDCode() << std::endl;
	}
    }
}
