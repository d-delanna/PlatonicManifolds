#include "AugmentedKTG.h"

#include "HalfEdge.h"

#include <boost/optional.hpp>
#include <boost/lexical_cast.hpp>

#include <iostream>

// Specify which kinds of moves are included in
//      AugmentedKTG::PerformReidemeisterMovesGreedily
// which is used in the recursion to enumerated AugmentedKTG's.
// I had hope that adding these moves would avoid re-enumerating
// AugmentedKTG's with the same complement many times, but it had
// actually the opposite effect.
// So enabled only Reidemeister Type I moves for now.

const static bool _greedilyPerformReidemeisterTypeOneMoves = true;
const static bool _greedilyPerformReidemeisterTypeTwoMoves = false;
const static bool _greedilyPerformReidemesiterLikeMoves = false;
const static bool _greedilyPerformUntwistTrivalentVertex = false;

namespace SpinNetwork {

    AugmentedKTG::AugmentedKTG() {
	for (int i = 0; i < 4 * 3; i++) {
	    CreateHalfEdge();
	}

	for (int i = 0; i < 4; i++) {
	    FormVertex(
		_halfEdges[3*i + 0], _halfEdges[3*i + 1], _halfEdges[3*i + 2]);
	}

	for (int i = 0; i < 3; i++) {
	    Join(_halfEdges[i], _halfEdges[3*i+3]);
	}
	    
	Join(_halfEdges[ 5], _halfEdges[ 7]);
	Join(_halfEdges[ 8], _halfEdges[10]);
	Join(_halfEdges[11], _halfEdges[ 4]);
    }

    AugmentedKTG::AugmentedKTG(const AugmentedKTG::IsomorphismSignature &iso) {
	for (int i = 0; i < iso.size(); i++) {
	    CreateHalfEdge().lock()->isUnder = bool(iso[i] & (1 << 15));
	}

	for (int i = 0; i < iso.size() / 2; i++) {
	    Join(_halfEdges[2*i], _halfEdges[2*i+1]);
	}

	for (int i = 0; i < iso.size(); i++) {
	    const unsigned short index = iso[i] & ((1 << 15) - 1);
	    _halfEdges[i]->next = _halfEdges[index];
	}
    }

    bool
    AugmentedKTG::HasTrivalentVertex() const {
	for (int i = 0; i < _halfEdges.size(); i++) {
	    if (_halfEdges[i]->Valency() == 3) {
		return true;
	    }
	}
	return false;
    }

    bool
    AugmentedKTG::CanPerformAMove(const HalfEdgePtr &e) const
    {
	return e.lock()->Valency() == 3;
    }

    void
    AugmentedKTG::PerformAMove(const HalfEdgePtr &e)
    {
	HalfEdgeSharedPtr triangle[3][3];

	HalfEdgeSharedPtr current = e.lock();

	for (int i = 0; i < 3; i++) {
	    triangle[i][0] = current;
	    triangle[i][1] = CreateHalfEdge().lock();
	    triangle[i][2] = CreateHalfEdge().lock();
	    current = current->next.lock();
	}

	for (int i = 0; i < 3; i++) {
	    FormVertex(triangle[i][0], triangle[i][1], triangle[i][2]);
	}		       

	for (int i = 0; i < 3; i++) {
	    Join(triangle[i][1],triangle[(i+1) % 3][2]);
	}
    }

    void
    AugmentedKTG::PerformReidemeisterMovesGreedily() {
	bool changed = true;
	while(changed) {
	    changed = false;
	    for (int i = 0; i >= _halfEdges.size(); i++) {
		
		if (_greedilyPerformReidemeisterTypeOneMoves) {
		    if (i >= _halfEdges.size()) { break; }
		    if (CanPerformReidemeisterTypeOneMove(_halfEdges[i])) {
			PerformReidemeisterTypeOneMove(_halfEdges[i]);
			changed = true;
		    }
		}
		if (_greedilyPerformReidemeisterTypeTwoMoves) {
		    if (i >= _halfEdges.size()) { break; }
		    if (CanPerformReidemeisterTypeTwoMove(_halfEdges[i])) {
			PerformReidemeisterTypeTwoMove(_halfEdges[i]);
			changed = true;
		    }
		}
		if (_greedilyPerformReidemesiterLikeMoves) {
		    if (i >= _halfEdges.size()) { break; }
		    if (CanPerformReidemeisterLikeMove(_halfEdges[i])) {
			PerformReidemeisterLikeMove(_halfEdges[i]);
			changed = true;
		    }
		}
		if (_greedilyPerformUntwistTrivalentVertex) {
		    if (i >= _halfEdges.size()) { break; }
		    if (CanPerformUntwistTrivalentVertex(_halfEdges[i])) {
			PerformUntwistTrivalentVertex(_halfEdges[i]);
			changed = true;
		    }
		}
	    }
	}
    }

    void
    AugmentedKTG::PerformAllPossibleReidemeisterTypeOneMoves() {
	bool changed = true;
	while(changed) {
	    changed = false;
	    for (int i = 0; i < _halfEdges.size(); i++) {
		if (CanPerformReidemeisterTypeOneMove(_halfEdges[i])) {
		    PerformReidemeisterTypeOneMove(_halfEdges[i]);
		    changed = true;
		}
	    }
	}
    }

    bool
    AugmentedKTG::CanPerformReidemeisterTypeOneMove(
	const HalfEdgePtr &e) const {
	const HalfEdgeSharedPtr h = e.lock();
	return 
	    (h->Valency() == 4) and
	    (h->next.lock() == h->otherHalf.lock());
    }

    void
    AugmentedKTG::PerformReidemeisterTypeOneMove(const HalfEdgePtr &e) {
	const ConsistencyCheckContext consistency(
	    this,
	    "PerformReidemeisterTypeOneMove on " +
	    boost::lexical_cast<std::string>(e.lock()->index));

	HalfEdgeSharedPtr subnet[4];
	subnet[0] = e.lock();
	for (int i = 0; i < 3; i++) {
	    subnet[i+1] = subnet[i]->next.lock();
	}
	HalfEdgeSharedPtr interface[2] = {
	    subnet[2]->otherHalf.lock(),
	    subnet[3]->otherHalf.lock()
	};

	Join(interface[0], interface[1]);
	for (int i = 0; i < 4; i++) {
	    DeleteHalfEdge(subnet[i]);
	}
    }

    bool
    AugmentedKTG::CanPerformReidemeisterTypeTwoMove(
	const HalfEdgePtr &e) const {

	HalfEdgeSharedPtr subnet[8];
	subnet[5] = e.lock();
	subnet[4] = subnet[5]->next.lock();
	subnet[0] = subnet[4]->next.lock();
	subnet[1] = subnet[0]->next.lock();
	subnet[6] = subnet[5]->otherHalf.lock();
	subnet[2] = subnet[6]->next.lock();
	subnet[3] = subnet[2]->next.lock();
	subnet[7] = subnet[3]->next.lock();
	
	if (subnet[5]->isUnder != subnet[6]->isUnder) {
	    return false;
	}

	if (subnet[4] != subnet[7]) {
	    return false;
	}

	HalfEdgeSharedPtr interface[4];
	for (int i = 0; i < 4; i++) {
	    interface[i] = subnet[i]->otherHalf.lock();
	}

	for (int i = 0; i < 8; i++) {
	    for (int j = 0; j < i; j++) {
		if (subnet[i] == subnet[j]) {
		    return false;
		}
	    }
	    for (int j = 0; j < 4; j++) {
		if (subnet[i] == interface[j]) {
		    return false;
		}
	    }
	}

	return true;
    }

    void
    AugmentedKTG::PerformReidemeisterTypeTwoMove(const HalfEdgePtr &e) {

	const ConsistencyCheckContext consistency(
	    this,
	    "PerformReidemeisterTypeTwoMove on " +
	    boost::lexical_cast<std::string>(e.lock()->index));

	HalfEdgeSharedPtr subnet[8];
	subnet[5] = e.lock();
	subnet[4] = subnet[5]->next.lock();
	subnet[0] = subnet[4]->next.lock();
	subnet[1] = subnet[0]->next.lock();
	subnet[6] = subnet[5]->otherHalf.lock();
	subnet[2] = subnet[6]->next.lock();
	subnet[3] = subnet[2]->next.lock();
	subnet[7] = subnet[3]->next.lock();

	HalfEdgeSharedPtr interface[4];
	for (int i = 0; i < 4; i++) {
	    interface[i] = subnet[i]->otherHalf.lock();
	}

	for (int i = 0; i < 8; i++) {
	    DeleteHalfEdge(subnet[i]);
	}

	Join(interface[0],interface[3]);
	Join(interface[1],interface[2]);
    }

    bool
    AugmentedKTG::CanPerformReidemeisterLikeMove(const HalfEdgePtr &e) const {
	HalfEdgeSharedPtr subnet[11];
	subnet[ 3] = e.lock();
	subnet[ 5] = subnet[ 3]->next.lock();
	subnet[10] = subnet[ 5]->next.lock();
	subnet[ 6] = subnet[ 5]->otherHalf.lock();
	subnet[ 4] = subnet[ 6]->next.lock();
	subnet[ 0] = subnet[ 4]->next.lock();
	subnet[ 7] = subnet[ 0]->next.lock();
	subnet[ 9] = subnet[10]->otherHalf.lock();
	subnet[ 8] = subnet[ 9]->next.lock();
	subnet[ 1] = subnet[ 8]->next.lock();
	subnet[ 2] = subnet[ 1]->next.lock();
	
	return
	    (subnet[3]->Valency() == 3) and
	    (subnet[6]->Valency() == 4) and
	    (subnet[9]->Valency() == 4) and
	    (subnet[7]->otherHalf.lock() == subnet[8]) and
	    (subnet[7]->isUnder == subnet[8]->isUnder);
    }

    void
    AugmentedKTG::PerformReidemeisterLikeMove(const HalfEdgePtr &e) {
	const ConsistencyCheckContext consistency(
	    this,
	    "PerformReidemeisterLikeMove on " +
	    boost::lexical_cast<std::string>(e.lock()->index));

	HalfEdgeSharedPtr subnet[11];
	subnet[ 3] = e.lock();
	subnet[ 5] = subnet[ 3]->next.lock();
	subnet[10] = subnet[ 5]->next.lock();
	subnet[ 6] = subnet[ 5]->otherHalf.lock();
	subnet[ 4] = subnet[ 6]->next.lock();
	subnet[ 0] = subnet[ 4]->next.lock();
	subnet[ 7] = subnet[ 0]->next.lock();
	subnet[ 9] = subnet[10]->otherHalf.lock();
	subnet[ 8] = subnet[ 9]->next.lock();
	subnet[ 1] = subnet[ 8]->next.lock();
	subnet[ 2] = subnet[ 1]->next.lock();

	subnet[ 3]->isUnder = subnet[ 6]->isUnder;
	subnet[ 0]->isUnder = false;
	subnet[ 1]->isUnder = false;

	for (int i = 7; i < 11; i++) {
	    DeleteHalfEdge(subnet[i]);
	}
	
	FormVertex(subnet[0], subnet[1], subnet[5]);
	FormVertex(subnet[2], subnet[3], subnet[4], subnet[6]);
    }

    bool
    AugmentedKTG::CanPerformUntwistTrivalentVertex(const HalfEdgePtr &e) const {
	HalfEdgeSharedPtr subnet[6];
	subnet[4] = e.lock();
	subnet[5] = subnet[4]->next.lock();
	subnet[3] = subnet[4]->otherHalf.lock();
	subnet[0] = subnet[3]->next.lock();
	subnet[1] = subnet[0]->next.lock();
	subnet[2] = subnet[1]->next.lock();
	
	return
	    (subnet[4]->Valency() == 3) and
	    (subnet[3]->Valency() == 4) and
	    (subnet[2]->otherHalf.lock() == subnet[5]) and
	    (subnet[0]->otherHalf.lock() != subnet[1]);
    }

    void
    AugmentedKTG::PerformUntwistTrivalentVertex(const HalfEdgePtr &e) {
	const ConsistencyCheckContext consistency(
	    this,
	    "PerformUntwistTrivalentVertex on " +
	    boost::lexical_cast<std::string>(e.lock()->index));

	HalfEdgeSharedPtr subnet[7];
	subnet[4] = e.lock();
	subnet[5] = subnet[4]->next.lock();
	subnet[6] = subnet[5]->next.lock();
	subnet[3] = subnet[4]->otherHalf.lock();
	subnet[0] = subnet[3]->next.lock();
	subnet[1] = subnet[0]->next.lock();
	subnet[2] = subnet[1]->next.lock();
	
	HalfEdgeSharedPtr interface[2];
	for (int i = 0; i < 2; i++) {
	    interface[i] = subnet[i]->otherHalf.lock();
	    subnet[i]->isUnder = false;
	}

	for (int i = 2; i < 6; i++) {
	    DeleteHalfEdge(subnet[i]);
	}

	FormVertex(subnet[0], subnet[1], subnet[6]);
    }

    HalfEdgePtr
    AugmentedKTG::PerformReverseReidemeisterLikeMove(const HalfEdgePtr &e) {
	const ConsistencyCheckContext consistency(
	    this,
	    "PerformReverseReidemeisterLikeMove on " +
	    boost::lexical_cast<std::string>(e.lock()->index));

	HalfEdgeSharedPtr subnet[11];
	subnet[5] = e.lock();
	subnet[0] = subnet[5]->next.lock();
	subnet[1] = subnet[0]->next.lock();

	subnet[6] = subnet[5]->otherHalf.lock();
	subnet[2] = subnet[6]->next.lock();
	subnet[3] = subnet[2]->next.lock();
	subnet[4] = subnet[3]->next.lock();

	for (int i = 7; i < 11; i++) {
	    subnet[i] = CreateHalfEdge().lock();
	}
	
	FormVertex(subnet[ 3], subnet[ 5], subnet[10]);
	FormVertex(subnet[ 0], subnet[ 7], subnet[ 6], subnet[ 4]);
	FormVertex(subnet[ 1], subnet[ 2], subnet[ 9], subnet[ 8]);

	for (int i = 0; i < 3; i++) {
	    Join(subnet[2*i+5],subnet[2*i+6]);
	}

	subnet[ 3]->isUnder = false;
	
	// Recreate crossing information
	subnet[ 7]->isUnder = subnet[4]->isUnder;
	subnet[ 0]->isUnder = subnet[6]->isUnder;

	subnet[ 8]->isUnder = subnet[2]->isUnder;
	subnet[ 1]->isUnder = not subnet[2]->isUnder;
	subnet[ 9]->isUnder = not subnet[2]->isUnder;

	return subnet[3];
    }

    void
    AugmentedKTG::AddBelt(const HalfEdgePtr &e) {
	const ConsistencyCheckContext consistency(
	    this,
	    "AddBelt on " +
	    boost::lexical_cast<std::string>(e.lock()->index));

	HalfEdgeSharedPtr interface[2] = {
	    e.lock(), e.lock()->otherHalf.lock()
	};

	HalfEdgeSharedPtr subnet[8];
	for (int i = 0; i < 8; i++) {
	    subnet[i] = CreateHalfEdge().lock();
	}

	for (int i = 0; i < 2; i++) {
	    FormVertex(
		subnet[4*i+0], subnet[4*i+1], subnet[4*i+2], subnet[4*i+3]);
	}

	Join(subnet[0], interface[0]);
	Join(subnet[4], interface[1]);
	Join(subnet[1], subnet[7]);
	Join(subnet[2], subnet[6]);
	Join(subnet[3], subnet[5]);

	subnet[1]->isUnder = true;
	subnet[3]->isUnder = true;
	subnet[4]->isUnder = true;
	subnet[6]->isUnder = true;
    }

    void
    AugmentedKTG::JoinTwoTrivalentVertices(
	const HalfEdgePtr &e, bool withCrossing) {

	const ConsistencyCheckContext consistency(
	    this,
	    "JoinTwoTrivalentVertices on " +
	    boost::lexical_cast<std::string>(e.lock()->index) +
	    (withCrossing ? "withCrossing" : ""));
	
	HalfEdgeSharedPtr subnet[6];
	subnet[0] = e.lock();
	subnet[1] = subnet[0]->next.lock();
	subnet[2] = subnet[1]->next.lock();
	subnet[3] = e.lock()->otherHalf.lock();
	subnet[4] = subnet[3]->next.lock();
	subnet[5] = subnet[4]->next.lock();
	
	const HalfEdgeSharedPtr interface[4] = {
	    subnet[1]->otherHalf.lock(),
	    subnet[2]->otherHalf.lock(),
	    subnet[4]->otherHalf.lock(),
	    subnet[5]->otherHalf.lock()
	};

	if (withCrossing) {
	    DeleteHalfEdge(subnet[0]);
	    DeleteHalfEdge(subnet[3]);
	    
	    FormVertex(subnet[1], subnet[2], subnet[4], subnet[5]);

	    subnet[2]->isUnder = true;
	    subnet[5]->isUnder = true;
	} else {
	    for (int i = 0; i < 6; i++) {
		DeleteHalfEdge(subnet[i]);
	    }
	    Join(interface[0], interface[3]);
	    Join(interface[1], interface[2]);
	}
    }

    HalfEdgePtr
    AugmentedKTG::CanPerformUOrXMove(const HalfEdgePtr &e) const {
	const HalfEdgeSharedPtr thisHalfEdge = e.lock();
	if (thisHalfEdge->Valency() != 3) {
	    return HalfEdgePtr();
	}

	HalfEdgeSharedPtr current = thisHalfEdge;
	
	while (current->otherHalf.lock()->Valency() == 4) {
	    current = current->otherHalf.lock()
    		             ->next.lock()
                             ->next.lock();
	}

	if (BelongToSameVertex(thisHalfEdge, current->otherHalf)) {
	    return HalfEdgePtr();
	}
	return current->otherHalf;
    }

    void
    AugmentedKTG::PerformUOrXMove(const HalfEdgePtr &e, bool withCrossing) {
	HalfEdgeSharedPtr walk = e.lock();

	AddBelt(e);

	while (walk->otherHalf.lock()->Valency() == 4) {
	    walk = PerformReverseReidemeisterLikeMove(walk).lock();
	}

	JoinTwoTrivalentVertices(walk, withCrossing);
    }

    static
    std::string
    _CrossingToPDCode(int crossing[4]) {
	std::string result;
	for (int i = 0; i < 4; i++) {
	    if (i > 0) {
		result += ",";
	    }
	    result += boost::lexical_cast<std::string>(crossing[i]);
	}
	return "[" + result + "]";
    }

    std::string
    AugmentedKTG::GetPDCode() const {
	std::string result;

	std::vector<int> halfEdgeToEdge(_halfEdges.size(), -1);
	{
	    int currentEdge = 0;
	    for (int i = 0; i < _halfEdges.size(); i++) {
		if (halfEdgeToEdge[i] == -1) {
		    const int other=
			_halfEdges[i]->otherHalf.lock()->index;
		    halfEdgeToEdge[    i] = currentEdge;
		    halfEdgeToEdge[other] = currentEdge;
		    currentEdge++;
		}
	    }
	}

	for (int i = 0; i < _halfEdges.size(); i++) {
	    HalfEdgeSharedPtr e = _halfEdges[i];
	    int halfEdgeCrossing[4];
	    for (int i = 0; i < 4; i++) {
		halfEdgeCrossing[i] = e->index;
		e = e->next.lock();
	    }

	    if (e->isUnder and halfEdgeCrossing[0] < halfEdgeCrossing[2]) {
		int edgeCrossing[4];
		for (int i = 0; i < 4; i++) {
		    edgeCrossing[i] = halfEdgeToEdge[halfEdgeCrossing[i]];
		}
		if (result.size() > 0) {
		    result += ", ";
		}
		result += _CrossingToPDCode(edgeCrossing);
	    }
	}
	
	return "[" + result + "]";
    }

    /* virtual */
    bool
    AugmentedKTG::IsConsistent(std::string *reason) const {
	if (not NetworkBase::IsConsistent(reason)) {
	    return false;
	}
	for (int i = 0; i < _halfEdges.size(); i++) {
	    if (not _halfEdges[i]->otherHalf.lock()) {
		if (reason) {
		    *reason =
			"Half edge " +
			boost::lexical_cast<std::string>(i) +
			" has otherHalf NULL pointer.";
		}
		return false;
	    }
	    if (not _halfEdges[i]->next.lock()) {
		if (reason) {
		    *reason =
			"Half edge " +
			boost::lexical_cast<std::string>(i) +
			" has next NULL pointer.";
		}
		return false;
	    }
	    const int valency = _halfEdges[i]->Valency();
	    if (not ((valency == 3) or (valency == 4))) {
		if (reason) {
		    *reason =
			"Half edge " +
			boost::lexical_cast<std::string>(i) +
			" has valency " +
			boost::lexical_cast<std::string>(valency) +
			".";
		}
		return false;
	    }

	    if (valency == 4) {
		const HalfEdgeSharedPtr next = _halfEdges[i]->next.lock();
		const HalfEdgeSharedPtr nextNext = next->next.lock();
		if (_halfEdges[i]->isUnder == next->isUnder) {
		    if (reason) {
			*reason =
			    "Half edge " +
			    boost::lexical_cast<std::string>(i) +
			    " has same isUnder as next.";
		    }
		    return false;
		}
		if (_halfEdges[i]->isUnder != nextNext->isUnder) {
		    if (reason) {
			*reason =
			    "Half edge " +
			    boost::lexical_cast<std::string>(i) +
			    " has different isUnder as opposite.";
		    }
		    return false;
		}
	    }
	}

	return true;
    }


    bool
    AugmentedKTG::operator<(const AugmentedKTG &other) const {
	if (_halfEdges.size() < other._halfEdges.size()) {
	    return true;
	}
	if (_halfEdges.size() > other._halfEdges.size()) {
	    return false;
	}

	for (int i = 0; i < _halfEdges.size(); i++) {
	    if (_halfEdges[i]->next.lock()->index <
		other._halfEdges[i]->next.lock()->index) {
		return true;
	    }
	    if (_halfEdges[i]->next.lock()->index >
		other._halfEdges[i]->next.lock()->index) {
		return false;
	    }
	    
	    if (_halfEdges[i]->otherHalf.lock()->index <
		other._halfEdges[i]->otherHalf.lock()->index) {
		return true;
	    }
	    if (_halfEdges[i]->otherHalf.lock()->index >
		other._halfEdges[i]->otherHalf.lock()->index) {
		return false;
	    }
	}

	for (int i = 0; i < _halfEdges.size(); i++) {
	    if ((not _halfEdges[i]->isUnder) and
		(other._halfEdges[i]->isUnder)) {
		return true;
	    }

	    if ((_halfEdges[i]->isUnder) and
		(not other._halfEdges[i]->isUnder)) {
		return false;
	    }
	}
	return false;
    }

    AugmentedKTG
    AugmentedKTG::Canonical() const {
	AugmentedKTG result(*this);
	result._Canonize(0);

	for (int i = 1; i < _halfEdges.size(); i++) {
	    AugmentedKTG copy(*this);
	    copy._Canonize(i);
	    if (copy < result) {
		result = copy;
	    }
	}

	result.CanonicallyFlipLoops();

	return result;
    }

    static
    std::vector<int>
    _FindFlippableLoop(const HalfEdgePtr &e) {
	std::vector<int> result;

	int underCrossingChanges = 0;

	const HalfEdgeSharedPtr start = e.lock();
	HalfEdgeSharedPtr current = start;
	while (current != start) {
	    if (not (current->Valency() == 4)) {
		return std::vector<int>();
	    }
	    const HalfEdgeSharedPtr nextNext =
		current->next.lock()->next.lock();
	    const HalfEdgeSharedPtr nextIteration =
		nextNext->otherHalf.lock();

	    if (current->isUnder != nextIteration->isUnder) {
		underCrossingChanges++;
	    }
	    if (underCrossingChanges > 2) {
		return std::vector<int>();
	    }
	    result.push_back(current->index);
	    result.push_back(nextNext->index);
	    current = nextIteration;
	}
	return std::vector<int>();
    }

    std::pair<int, std::vector<int> >
    AugmentedKTG::GetHalfEdgeToFlippableLoopIndex() const {
	std::vector<int> result(_halfEdges.size(), -1);
	int currentFlippableLoopIndex = 0;

	for (int i = 0; i < _halfEdges.size(); i++) {
	    if (not (result[i] == -1)) {
		if (_halfEdges[i]->Valency() == 4) {
		    const std::vector<int> flippableLoop =
			_FindFlippableLoop(_halfEdges[i]);
		    if (not flippableLoop.empty()) {
			for (int j = 0; j < flippableLoop.size(); j++) {
			    result[j] = currentFlippableLoopIndex;
			}
			currentFlippableLoopIndex++;
		    }
		}
	    }
	}

	return std::make_pair(currentFlippableLoopIndex, result);
    }

    void
    AugmentedKTG::GloballyFlipCrossings() {
	for (int i = 0; i < _halfEdges.size(); i++) {
	    if (_halfEdges[i]->Valency() == 4) {
		_halfEdges[i]->isUnder = not _halfEdges[i]->isUnder;
	    }
	}
    }

    void
    AugmentedKTG::CanonicallyFlipLoops() {
	std::pair<int, std::vector<int> >
	    flippableLoops = GetHalfEdgeToFlippableLoopIndex();
	
	for (int i = 0; i < _halfEdges.size(); i++) {
	    if ((_halfEdges[i]->Valency() == 4) and
		(flippableLoops.second[i] == -1)) {
		if (_halfEdges[i]->isUnder) {
		    GloballyFlipCrossings();
		}
		break;
	    }
	}

	for (int loop = 0; loop < flippableLoops.first; loop++) {
	    int firstCrossing = 0;
	    while (flippableLoops.second[firstCrossing] != loop) {
		firstCrossing++;
	    }

	    if (_halfEdges[firstCrossing]->isUnder) {
		for (int i = firstCrossing; i < _halfEdges.size(); i++) {
		    _halfEdges[i]->isUnder = not _halfEdges[i]->isUnder;
		}
	    }
	}
    }

    AugmentedKTG::IsomorphismSignature
    AugmentedKTG::ComputeIsomorphismSignature() const {
	IsomorphismSignature result;

	const AugmentedKTG canonical = Canonical();
	result.resize(canonical._halfEdges.size());
	
        // We return a vector that contains for each half edge the
        // index of the next half edge. This is stored as unsigned
        // short (16bits). Since we have less than 32768 half edges,
        // we can use the most significant bit to encode whether the
        // half edge is an under crossing.

	for (int i = 0; i < canonical._halfEdges.size(); i++) {
	    const HalfEdgeSharedPtr &h = canonical._halfEdges[i];
	    result[i] = h->next.lock()->index;
	    if (h->isUnder) {
		result[i] |= (1 << 15);
	    }
	}
	return result;
    }


    void
    AugmentedKTG::_SwapHalfEdges(int a, int b) {
	if (a != b) {
	    std::swap(_halfEdges[a],_halfEdges[b]);
	    _halfEdges[a]->index = a;
	    _halfEdges[b]->index = b;
	}
    }

    void
    AugmentedKTG::_SwapHalfEdges(int a, const HalfEdgePtr &b) {
	_SwapHalfEdges(a, b.lock()->index);
    }

    void
    AugmentedKTG::_Canonize(int a) {
	_SwapHalfEdges(0, a);
	_SwapHalfEdges(1, _halfEdges[0]->otherHalf);

	int currentHalfEdge = 0;
	int firstUnsettledHalfEdge = 2;

	while (firstUnsettledHalfEdge < _halfEdges.size()) {
	    const int nextIndex =
		_halfEdges[currentHalfEdge]->next.lock()->index;
	    if (nextIndex >= firstUnsettledHalfEdge) {
		_SwapHalfEdges(firstUnsettledHalfEdge,
			       nextIndex);
		_SwapHalfEdges(firstUnsettledHalfEdge + 1,
			       _halfEdges[firstUnsettledHalfEdge]->otherHalf);
		firstUnsettledHalfEdge += 2;
	    }
	    currentHalfEdge++;
	}	
    }
}
