#ifndef __SPINNETWORK_SIMPLERECURSION__
#define __SPINNETWORK_SIMPLERECURSION__

#include "AugmentedKTG.h"

#include <set>

namespace SpinNetwork {
    typedef std::set<AugmentedKTG::IsomorphismSignature> AugKTGIsoSigSet;

    AugKTGIsoSigSet  RecurseAugmentedKTG(int numAMoves);
}

#endif
